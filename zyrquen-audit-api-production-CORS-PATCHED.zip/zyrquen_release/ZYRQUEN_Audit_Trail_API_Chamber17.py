"""Production baseline for the ZYRQUEN audit API.

This service stores audit records in SQLite, authenticates with a bearer API key
from the environment, and generates real PDF files. It intentionally makes no
claim that it performs Dilithium/HSM/legal certification; those integrations
must be supplied separately.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import re
import secrets
import sqlite3
import time
import uuid
from contextlib import asynccontextmanager, contextmanager
from pathlib import Path
from typing import Generator, Optional

from fastapi import Depends, FastAPI, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, Response
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel, Field, field_validator
from prometheus_client import CollectorRegistry, CONTENT_TYPE_LATEST, Counter, Gauge, Histogram, generate_latest
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

APP_VERSION = "2.0.0"
DB_PATH = Path(os.getenv("AUDIT_DB_PATH", "./data/audit.db"))
REPORT_DIR = Path(os.getenv("AUDIT_REPORT_DIR", "./data/reports"))
API_KEY_ENV = "ZYRQUEN_API_KEY"
CANONICAL_BLOCK = int(os.getenv("CANONICAL_BLOCK_HEIGHT", "849202"))
GENESIS_HASH = os.getenv(
    "GENESIS_HASH",
    "909ab814479844d8a14816bed34cdbb07528e18501da86fc4691763a43fa4c68",
)

@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    yield


app = FastAPI(
    title="ZYRQUEN Audit Trail API",
    description="Persistent audit-record service. Cryptographic/HSM integrations are explicit extension points.",
    version=APP_VERSION,
    lifespan=lifespan,
)
_cors_origins_env = os.getenv("ZYRQUEN_CORS_ORIGINS", "*")
_cors_origins = [o.strip() for o in _cors_origins_env.split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=_cors_origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)

bearer = HTTPBearer(auto_error=False)


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created)),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if hasattr(record, "event"):
            payload["event"] = record.event
        for key in ("request_id", "method", "path", "status_code", "duration_ms", "client_ip"):
            if hasattr(record, key):
                payload[key] = getattr(record, key)
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))


logger = logging.getLogger("zyrquen.api")
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    logger.addHandler(handler)
    logger.setLevel(os.getenv("LOG_LEVEL", "INFO").upper())
    logger.propagate = False

METRICS_REGISTRY = CollectorRegistry()

REQUESTS_TOTAL = Counter(
    "zyrquen_http_requests_total",
    "Total HTTP requests handled by the API",
    ["method", "path", "status_code"],
    registry=METRICS_REGISTRY,
)
REQUEST_DURATION = Histogram(
    "zyrquen_http_request_duration_seconds",
    "HTTP request duration in seconds",
    ["method", "path"],
    registry=METRICS_REGISTRY,
)
AUDIT_RECORDS_TOTAL = Counter(
    "zyrquen_audit_records_created_total",
    "Total audit records created",
    registry=METRICS_REGISTRY,
)
REPORTS_TOTAL = Counter(
    "zyrquen_reports_created_total",
    "Total PDF reports created",
    registry=METRICS_REGISTRY,
)
DB_RECORDS = Gauge(
    "zyrquen_audit_records_stored",
    "Current number of audit records stored in SQLite",
    registry=METRICS_REGISTRY,
)


def metric_path(path: str) -> str:
    path = re.sub(r"/api/v1/audit/replay/[^/]+$", "/api/v1/audit/replay/{seal_id}", path)
    path = re.sub(r"/api/v1/audit/report/[^/]+/download$", "/api/v1/audit/report/{report_id}/download", path)
    return path


@app.middleware("http")
async def observe_requests(request, call_next):
    request_id = request.headers.get("X-Request-ID", str(uuid.uuid4()))
    started = time.perf_counter()
    response = None
    try:
        response = await call_next(request)
        return response
    finally:
        duration = time.perf_counter() - started
        path = metric_path(request.url.path)
        status_code = str(response.status_code if response else 500)
        REQUESTS_TOTAL.labels(request.method, path, status_code).inc()
        REQUEST_DURATION.labels(request.method, path).observe(duration)
        logger.info(
            "request_complete",
            extra={
                "event": "request_complete",
                "request_id": request_id,
                "method": request.method,
                "path": path,
                "status_code": int(status_code),
                "duration_ms": round(duration * 1000, 3),
                "client_ip": request.client.host if request.client else None,
            },
        )
        if response is not None:
            response.headers["X-Request-ID"] = request_id


class TelemetryResponse(BaseModel):
    status: str
    block_height: int
    canonical_seals_count: int
    genesis_hash: str
    generated_at: float


class AuditRecordCreate(BaseModel):
    seal_id: Optional[int] = Field(default=None, ge=0, le=10_000_000)
    chamber: str = Field(min_length=1, max_length=120)
    module: str = Field(min_length=1, max_length=120)
    event_type: str = Field(min_length=1, max_length=120)
    details: str = Field(min_length=1, max_length=20_000)
    legal_sections: list[int] = Field(default_factory=list)
    forensic_ready: bool = False

    @field_validator("legal_sections")
    @classmethod
    def validate_sections(cls, value: list[int]) -> list[int]:
        if any(section < 1 or section > 999 for section in value):
            raise ValueError("legal_sections must contain positive section numbers")
        return sorted(set(value))


class AuditRecord(AuditRecordCreate):
    record_id: str
    created_at: float
    previous_hash: str
    record_hash: str


class ReplayResponse(BaseModel):
    seal_id: int
    status: str
    stages_executed: list[str]
    matching_record_ids: list[str]
    replayed_at: float


class ReportRequest(BaseModel):
    block_height: int = Field(default=CANONICAL_BLOCK, ge=0)
    include_records: bool = True


class ReportResponse(BaseModel):
    report_id: str
    file_name: str
    download_url: str
    sha256: str
    created_at: float


@contextmanager
def db_connection() -> Generator[sqlite3.Connection, None, None]:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    try:
        yield connection
        connection.commit()
    finally:
        connection.close()


def init_db() -> None:
    with db_connection() as db:
        db.execute(
            """CREATE TABLE IF NOT EXISTS audit_records (
                record_id TEXT PRIMARY KEY,
                seal_id INTEGER,
                created_at REAL NOT NULL,
                chamber TEXT NOT NULL,
                module TEXT NOT NULL,
                event_type TEXT NOT NULL,
                details TEXT NOT NULL,
                legal_sections TEXT NOT NULL,
                forensic_ready INTEGER NOT NULL,
                previous_hash TEXT NOT NULL,
                record_hash TEXT NOT NULL UNIQUE
            )"""
        )
        db.execute(
            """CREATE TABLE IF NOT EXISTS reports (
                report_id TEXT PRIMARY KEY,
                file_name TEXT NOT NULL,
                sha256 TEXT NOT NULL,
                created_at REAL NOT NULL
            )"""
        )




def require_api_key(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer),
) -> str:
    expected = os.getenv(API_KEY_ENV)
    if not expected:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"{API_KEY_ENV} is not configured",
        )
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise HTTPException(status_code=401, detail="Bearer token required")
    if not hmac.compare_digest(credentials.credentials, expected):
        raise HTTPException(status_code=403, detail="Invalid API key")
    return credentials.credentials


def row_to_record(row: sqlite3.Row) -> AuditRecord:
    return AuditRecord(
        seal_id=row["seal_id"],
        chamber=row["chamber"],
        module=row["module"],
        event_type=row["event_type"],
        details=row["details"],
        legal_sections=json.loads(row["legal_sections"]),
        forensic_ready=bool(row["forensic_ready"]),
        record_id=row["record_id"],
        created_at=row["created_at"],
        previous_hash=row["previous_hash"],
        record_hash=row["record_hash"],
    )


def calculate_record_hash(
    record_id: str,
    created_at: float,
    payload: AuditRecordCreate,
    previous_hash: str,
) -> str:
    canonical = {
        "record_id": record_id,
        "created_at": created_at,
        "seal_id": payload.seal_id,
        "chamber": payload.chamber,
        "module": payload.module,
        "event_type": payload.event_type,
        "details": payload.details,
        "legal_sections": payload.legal_sections,
        "forensic_ready": payload.forensic_ready,
        "previous_hash": previous_hash,
    }
    encoded = json.dumps(canonical, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


@app.get("/healthz")
def healthz() -> dict[str, str]:
    return {"status": "ok", "version": APP_VERSION}


@app.get("/metrics")
def metrics():
    with db_connection() as db:
        DB_RECORDS.set(db.execute("SELECT COUNT(*) FROM audit_records").fetchone()[0])
    return Response(generate_latest(METRICS_REGISTRY), media_type=CONTENT_TYPE_LATEST)


@app.get("/api/v1/telemetry", response_model=TelemetryResponse)
def get_telemetry() -> TelemetryResponse:
    with db_connection() as db:
        count = db.execute("SELECT COUNT(*) FROM audit_records").fetchone()[0]
    return TelemetryResponse(
        status="operational",
        block_height=CANONICAL_BLOCK,
        canonical_seals_count=count,
        genesis_hash=GENESIS_HASH,
        generated_at=time.time(),
    )


@app.post("/api/v1/audit/records", response_model=AuditRecord, status_code=201)
def create_audit_record(payload: AuditRecordCreate, _: str = Depends(require_api_key)) -> AuditRecord:
    record_id = str(uuid.uuid4())
    created_at = time.time()
    with db_connection() as db:
        previous = db.execute("SELECT record_hash FROM audit_records ORDER BY rowid DESC LIMIT 1").fetchone()
        previous_hash = previous["record_hash"] if previous else GENESIS_HASH
        record_hash = calculate_record_hash(record_id, created_at, payload, previous_hash)
        db.execute(
            """INSERT INTO audit_records
            (record_id, seal_id, created_at, chamber, module, event_type, details,
             legal_sections, forensic_ready, previous_hash, record_hash)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (record_id, payload.seal_id, created_at, payload.chamber, payload.module,
             payload.event_type, payload.details, json.dumps(payload.legal_sections),
             int(payload.forensic_ready), previous_hash, record_hash),
        )
        row = db.execute("SELECT * FROM audit_records WHERE record_id = ?", (record_id,)).fetchone()
    AUDIT_RECORDS_TOTAL.inc()
    DB_RECORDS.inc()
    return row_to_record(row)


@app.get("/api/v1/audit/records", response_model=list[AuditRecord])
def get_audit_records(
    chamber: Optional[str] = Query(default=None, min_length=1, max_length=120),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    _: str = Depends(require_api_key),
) -> list[AuditRecord]:
    sql = "SELECT * FROM audit_records"
    params: list[object] = []
    if chamber:
        sql += " WHERE chamber = ?"
        params.append(chamber)
    sql += " ORDER BY rowid DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    with db_connection() as db:
        rows = db.execute(sql, params).fetchall()
    return [row_to_record(row) for row in rows]


@app.post("/api/v1/audit/replay/{seal_id}", response_model=ReplayResponse)
def replay_seal(seal_id: int, _: str = Depends(require_api_key)) -> ReplayResponse:
    if seal_id < 0 or seal_id > 10_000_000:
        raise HTTPException(status_code=422, detail="seal_id is outside the allowed range")
    with db_connection() as db:
        rows = db.execute(
            "SELECT record_id FROM audit_records WHERE seal_id = ? ORDER BY rowid ASC", (seal_id,)
        ).fetchall()
    if not rows:
        raise HTTPException(status_code=404, detail="Seal has no stored audit records")
    return ReplayResponse(
        seal_id=seal_id,
        status="REPLAY_COMPLETE",
        stages_executed=[f"STAGE-{index:02d}" for index in range(1, 13)],
        matching_record_ids=[row["record_id"] for row in rows],
        replayed_at=time.time(),
    )


def make_report(report_id: str, include_records: bool) -> tuple[Path, str]:
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    path = REPORT_DIR / f"{report_id}.pdf"
    pdf = canvas.Canvas(str(path), pagesize=A4)
    pdf.setTitle(f"Audit report {report_id}")
    pdf.drawString(50, 800, "ZYRQUEN Audit Trail Report")
    pdf.drawString(50, 782, f"Report ID: {report_id}")
    pdf.drawString(50, 764, f"Generated at UTC epoch: {time.time():.3f}")
    if include_records:
        with db_connection() as db:
            total = db.execute("SELECT COUNT(*) FROM audit_records").fetchone()[0]
        pdf.drawString(50, 746, f"Stored audit records: {total}")
    pdf.drawString(50, 710, "This document reports application data; it is not a legal or cryptographic certification.")
    pdf.save()
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    return path, digest


@app.post("/api/v1/audit/report/generate", response_model=ReportResponse, status_code=201)
def generate_audit_report(payload: ReportRequest, _: str = Depends(require_api_key)) -> ReportResponse:
    if payload.block_height != CANONICAL_BLOCK:
        raise HTTPException(status_code=400, detail="block_height is not the configured canonical block")
    report_id = f"ZYR-AUD-{secrets.token_hex(4).upper()}"
    path, digest = make_report(report_id, payload.include_records)
    created_at = time.time()
    with db_connection() as db:
        db.execute(
            "INSERT INTO reports (report_id, file_name, sha256, created_at) VALUES (?, ?, ?, ?)",
            (report_id, path.name, digest, created_at),
        )
    REPORTS_TOTAL.inc()
    return ReportResponse(
        report_id=report_id,
        file_name=path.name,
        download_url=f"/api/v1/audit/report/{report_id}/download",
        sha256=digest,
        created_at=created_at,
    )


@app.get("/api/v1/audit/report/{report_id}/download")
def download_report(report_id: str, _: str = Depends(require_api_key)) -> FileResponse:
    with db_connection() as db:
        row = db.execute("SELECT file_name FROM reports WHERE report_id = ?", (report_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Report not found")
    path = REPORT_DIR / row["file_name"]
    if not path.is_file():
        raise HTTPException(status_code=410, detail="Report file is no longer available")
    return FileResponse(path, media_type="application/pdf", filename=path.name)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("ZYRQUEN_Audit_Trail_API_Chamber17:app", host="127.0.0.1", port=8000)
