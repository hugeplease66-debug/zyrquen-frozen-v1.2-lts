# CI/CD Guide — ZYRQUEN Audit Trail API

ไฟล์ workflow อยู่ที่ `.github/workflows/ci-cd.yml` และทำงานบน GitHub Actions โดยมี 3 งานหลัก:

| Job | ทำงานเมื่อ | ผลลัพธ์ |
|---|---|---|
| `test` | Pull request, push ไป `main`, version tag และ manual run | ติดตั้ง dependencies และรัน Automated Tests ทั้งหมด |
| `docker-build` | หลัง `test` ผ่าน | Build Docker image โดยไม่ publish |
| `publish` | เฉพาะ push tag รูปแบบ `v*.*.*` | Build และ publish image ไป GitHub Container Registry (GHCR) |

## การเปิดใช้งาน

วางไฟล์ workflow ไว้ที่:

```text
.github/workflows/ci-cd.yml
```

จากนั้น commit และ push ไปยัง branch `main`:

```bash
git add .github/workflows/ci-cd.yml CI_CD_GUIDE.md
git commit -m "ci: add automated tests and docker image pipeline"
git push origin main
```

ทุก Pull Request ที่มุ่งไป `main` จะรัน test และ Docker build โดยอัตโนมัติ ส่วนการ push ไป `main` จะทำแบบเดียวกัน

## การ publish Docker image

ระบบจะ publish เฉพาะเมื่อสร้าง version tag เช่น:

```bash
git tag v2.0.0
git push origin v2.0.0
```

image จะถูกส่งไปที่:

```text
ghcr.io/<owner>/<repository>:v2.0.0
ghcr.io/<owner>/<repository>:sha-<commit>
```

ใน workflow ใช้ `GITHUB_TOKEN` ของ GitHub Actions และจำกัด `packages: write` ไว้เฉพาะ publish job เท่านั้น จึงไม่ต้องสร้าง PAT เพิ่มสำหรับ repository เดียวกัน

หากต้องการให้ package เป็น public ให้เข้าไปตั้งค่า visibility ของ package ใน GitHub หลัง publish ครั้งแรกตามนโยบายขององค์กร ไม่ควรใส่ Docker registry password หรือ API key ลงใน workflow

## GitHub branch protection ที่แนะนำ

ควรตั้ง branch protection ของ `main` ให้ต้องผ่าน status check ชื่อ `Automated tests` และ `Build Docker image` ก่อน merge รวมถึงบังคับ pull request review และป้องกันการ push โดยตรงตามระดับความเสี่ยงของโครงการ

## การตรวจสอบผลลัพธ์

ดูผล workflow ได้ที่แท็บ **Actions** ของ repository หาก test ล้มเหลว job build และ publish จะไม่ทำงาน เนื่องจากมี `needs: test` และ publish ยังขึ้นกับทั้ง test และ docker-build

การ build ปกติจะใช้ GitHub Actions cache แต่ไม่มีการเก็บ secret ใน image เนื่องจาก Dockerfile ใช้ `.env` ผ่าน runtime environment และ `.dockerignore` กันไฟล์ `.env` ออกจาก build context

## ข้อจำกัด

Workflow นี้ build image อัตโนมัติและ publish เมื่อมี version tag แต่ยังไม่ได้ deploy ไปยัง server ใดโดยอัตโนมัติ หากต้องการ deployment ต่อไป ต้องเพิ่ม job แยกที่เชื่อมต่อ platform ปลายทางผ่าน GitHub Environment เช่น `production` พร้อม protected secrets, approval gate และคำสั่ง rollback ที่ชัดเจน


## Pipeline gates สำหรับ Unit, Contract และ Security

Workflow ปัจจุบันแยก validation เป็นสาม jobs ได้แก่ `unit-tests`, `contract-tests` และ `security-scan` โดย job `docker-build` จะเริ่มได้เมื่อทั้งสาม jobs ผ่านแล้ว ส่วน `publish` จะทำงานเฉพาะ version tag รูปแบบ `v*.*.*`

| Job | สิ่งที่ทำ | ผลลัพธ์ |
|---|---|---|
| `unit-tests` | รัน regression, backup, DR, security-tooling และ performance-tooling tests | test result ใน Actions |
| `contract-tests` | export/validate OpenAPI และตรวจ runtime responses กับ schema | `openapi.json` artifact |
| `security-scan` | `pip-audit`, Bandit และ Trivy filesystem scan สำหรับ vulnerability, misconfiguration และ secret | JSON security artifacts |
| `docker-build` | Build image หลัง test/security gates ผ่าน | build result/cache |
| `publish` | publish ไป GHCR เฉพาะ version tag | immutable/tagged image |

Workflow ใช้ `contents: read` เป็นค่าเริ่มต้น และให้ `packages: write` เฉพาะ publish job เท่านั้น การอัปโหลด security reports ใช้ `if: always()` เพื่อให้ตรวจผลได้แม้ scanner job ล้มเหลว แต่ job ยังคง fail ตาม severity policy

## Security scan policy

`pip-audit` ตรวจ dependencies ใน runtime และ test requirements, Bandit ตรวจ Python source โดยตัด tests/performance ออกจาก scope ที่ซ้ำซ้อน และ Trivy ตรวจ repository filesystem ด้วย scanners `vuln`, `misconfig` และ `secret` เฉพาะระดับ `HIGH,CRITICAL` และ ignore unfixed findings ตามค่า workflow ปัจจุบัน

ก่อนเปิดใช้จริง ควรกำหนด policy ว่า finding ใดอนุญาตให้มี exception ได้ ใครเป็นผู้อนุมัติ และ exception หมดอายุเมื่อใด ไม่ควรใส่ token, API key, TLS key หรือ production `.env` ลงใน repository เพื่อให้ scanner ไม่พบ secret จริง

## วิธีตรวจบนเครื่องนักพัฒนา

```bash
python3 -m pip install -r requirements-ci.txt
./run_api_tests.sh
python3 tools/export_openapi.py
python3 tools/validate_openapi.py
pip-audit -r requirements-audit-api-runtime.txt -r requirements-audit-api.txt
bandit -r . -x tests,performance,.git
```

Trivy filesystem scan ต้องติดตั้ง Trivy ตามวิธีของ operating system ก่อนรัน:

```bash
trivy fs --scanners vuln,misconfig,secret --severity HIGH,CRITICAL --ignore-unfixed .
```

Load test ด้วย Locust ไม่ควรถูกรันในทุก pull request เพราะสร้าง traffic และข้อมูล โดยให้รันเฉพาะ staging ผ่าน `PERFORMANCE_TESTING_GUIDE.md`
