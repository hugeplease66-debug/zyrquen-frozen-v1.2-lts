#!/usr/bin/env bash
set -Eeuo pipefail

TARGET_URL="${TARGET_URL:-}"
USERS="${USERS:-10}"
SPAWN_RATE="${SPAWN_RATE:-2}"
RUN_TIME="${RUN_TIME:-60s}"
LOAD_TEST_API_KEY="${LOAD_TEST_API_KEY:-}"

[[ -n "$TARGET_URL" ]] || { echo "TARGET_URL is required" >&2; exit 2; }
[[ "$TARGET_URL" =~ ^https?:// ]] || { echo "TARGET_URL must start with http:// or https://" >&2; exit 2; }
[[ "$LOAD_TEST_CONFIRM" == "YES" ]] || { echo "Refusing load test: set LOAD_TEST_CONFIRM=YES" >&2; exit 2; }
[[ -n "$LOAD_TEST_API_KEY" ]] || { echo "LOAD_TEST_API_KEY is required" >&2; exit 2; }

host="${TARGET_URL#*://}"
host="${host%%/*}"
if [[ "$host" =~ (prod|production|live) ]] && [[ "${ALLOW_PRODUCTION_LOAD_TEST:-NO}" != "YES" ]]; then
  echo "Refusing target that looks like production: $host" >&2
  echo "Use a staging target, or obtain explicit approval and set ALLOW_PRODUCTION_LOAD_TEST=YES." >&2
  exit 2
fi

exec locust -f "$(dirname "$0")/locustfile.py" \
  --headless \
  --host "$TARGET_URL" \
  --users "$USERS" \
  --spawn-rate "$SPAWN_RATE" \
  --run-time "$RUN_TIME" \
  --only-summary \
  --csv "${LOCUST_CSV_PREFIX:-locust-results}" \
  --html "${LOCUST_HTML_REPORT:-locust-report.html}"
