import os
import uuid

from locust import HttpUser, between, task


class ZyrquenApiUser(HttpUser):
    wait_time = between(0.5, 2.0)

    def on_start(self):
        self.api_key = os.getenv("LOAD_TEST_API_KEY", "load-test-only-key")
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "X-Request-ID": str(uuid.uuid4()),
        }
        self.seal_id = int(os.getenv("LOAD_TEST_SEAL_ID", "14903001"))
        self.report_id = None

        response = self.client.post(
            "/api/v1/audit/records",
            json={
                "seal_id": self.seal_id,
                "chamber": "LOAD-TEST",
                "module": "performance",
                "event_type": "LOAD_TEST_SEED",
                "details": "Synthetic load-test record; safe to delete after the test.",
                "legal_sections": [9, 28],
                "forensic_ready": False,
            },
            headers=self.headers,
            name="POST /api/v1/audit/records [seed]",
        )
        if response.status_code not in (201, 409):
            response.failure(f"seed failed: HTTP {response.status_code}")

    @task(4)
    def healthz(self):
        self.client.get("/healthz", name="GET /healthz")

    @task(2)
    def telemetry(self):
        self.client.get("/api/v1/telemetry", name="GET /api/v1/telemetry")

    @task(1)
    def metrics(self):
        self.client.get("/metrics", name="GET /metrics")

    @task(4)
    def list_records(self):
        self.client.get(
            "/api/v1/audit/records?limit=50&offset=0",
            headers=self.headers,
            name="GET /api/v1/audit/records",
        )

    @task(2)
    def create_record(self):
        self.client.post(
            "/api/v1/audit/records",
            json={
                "seal_id": self.seal_id,
                "chamber": "LOAD-TEST",
                "module": "performance",
                "event_type": "LOAD_TEST_EVENT",
                "details": f"Synthetic event {uuid.uuid4()}",
                "legal_sections": [9, 28],
                "forensic_ready": False,
            },
            headers=self.headers,
            name="POST /api/v1/audit/records",
        )

    @task(2)
    def replay(self):
        self.client.post(
            f"/api/v1/audit/replay/{self.seal_id}",
            headers=self.headers,
            name="POST /api/v1/audit/replay/{seal_id}",
        )

    @task(1)
    def generate_and_download_report(self):
        response = self.client.post(
            "/api/v1/audit/report/generate",
            json={"include_records": False},
            headers=self.headers,
            name="POST /api/v1/audit/report/generate",
        )
        if response.status_code == 201:
            self.report_id = response.json().get("report_id")
        if self.report_id:
            self.client.get(
                f"/api/v1/audit/report/{self.report_id}/download",
                headers=self.headers,
                name="GET /api/v1/audit/report/{report_id}/download",
            )
