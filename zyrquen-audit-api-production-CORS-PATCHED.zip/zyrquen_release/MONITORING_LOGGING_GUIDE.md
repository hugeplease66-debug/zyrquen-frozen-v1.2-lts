# Monitoring and Logging Guide

## ภาพรวม

ชุด monitoring นี้ประกอบด้วย Prometheus สำหรับ scrape metrics, Grafana สำหรับ dashboard, Prometheus alert rules สำหรับตรวจจับเหตุผิดปกติ และ JSON logging ของ API ที่ส่งออกทาง stdout/stderr เพื่อให้ Docker หรือ log collector ภายนอกจัดเก็บต่อได้

```text
API :8000/metrics  ->  Prometheus :9090  ->  Grafana :3000
API stdout JSON    ->  Docker json-file rotation / external log collector
```

ระบบจะไม่ส่ง API key, Authorization header หรือ request body เข้า application log โดย middleware บันทึกเฉพาะ request ID, method, normalized path, status code, duration และ client IP

## Metrics ที่มีให้

| Metric | ประเภท | ความหมาย |
|---|---|---|
| `zyrquen_http_requests_total` | Counter | จำนวน request แยกตาม method, normalized path และ status code |
| `zyrquen_http_request_duration_seconds` | Histogram | latency ของ request |
| `zyrquen_audit_records_created_total` | Counter | จำนวน audit records ที่สร้าง |
| `zyrquen_reports_created_total` | Counter | จำนวน PDF reports ที่สร้าง |
| `zyrquen_audit_records_stored` | Gauge | จำนวน records ที่อยู่ใน SQLite ปัจจุบัน |

Path ที่มี ID เช่น seal ID และ report ID จะถูก normalize ก่อนติด label เพื่อลด Prometheus label cardinality

## เริ่ม monitoring stack

ต้องตั้งค่าใน `.env` ก่อน:

```bash
cp .env.example .env
# ตั้งค่า ZYRQUEN_API_KEY
# ตั้งค่า GRAFANA_ADMIN_USER และ GRAFANA_ADMIN_PASSWORD
docker compose -f docker-compose.prod.yml up -d --build
```

ตรวจสอบสถานะ:

```bash
docker compose -f docker-compose.prod.yml ps
curl -fsS http://127.0.0.1:8000/healthz
curl -fsS http://127.0.0.1:3000/api/health
```

Prometheus อยู่ที่ `http://127.0.0.1:9090` ภายใน network ของ Compose และ Grafana อยู่ที่ `http://127.0.0.1:3000` เฉพาะบน host เครื่องนั้น ค่าเริ่มต้นนี้ไม่เปิด Prometheus ออกสู่ public network

เข้า Grafana ด้วย `GRAFANA_ADMIN_USER` และ `GRAFANA_ADMIN_PASSWORD` ที่ตั้งไว้ใน `.env` โดย datasource Prometheus และ dashboard `ZYRQUEN Audit API` จะถูก provision อัตโนมัติ

## ตรวจสอบ metrics

จาก host จะไม่สามารถเรียก `/metrics` ผ่าน Nginx public endpoint ได้ เพราะ Nginx block path นี้ไว้เพื่อไม่เปิด internal metrics สู่ภายนอก หากต้องการดู raw metrics ให้ใช้ Prometheus ภายใน หรือสั่งจาก container API:

```bash
docker compose -f docker-compose.prod.yml exec audit-api \
  python -c 'import urllib.request; print(urllib.request.urlopen("http://127.0.0.1:8000/metrics").read().decode())'
```

Prometheus scrape target คือ `audit-api:8000/metrics` ตามไฟล์ `monitoring/prometheus/prometheus.yml`

## Alert rules

มี alert เริ่มต้นสี่รายการ:

| Alert | เงื่อนไข |
|---|---|
| `ZyrquenApiTargetDown` | Prometheus scrape API ไม่ได้เกิน 2 นาที |
| `ZyrquenApiHigh5xxRate` | 5xx response มากกว่า 5% ต่อเนื่อง 5 นาที |
| `ZyrquenApiHighLatency` | p95 latency สูงกว่า 1 วินาทีต่อเนื่อง 10 นาที |
| `ZyrquenAuditRecordGrowth` | สร้าง records มากกว่า 100,000 รายการใน 1 ชั่วโมง |

Prometheus จะประเมิน rules อัตโนมัติ แต่การส่ง notification ต้องตั้งค่า Alertmanager หรือ Grafana Alerting เพิ่มเองตามช่องทางขององค์กร เช่น email, Slack หรือ PagerDuty ไม่ควรใส่ webhook token ลงใน repository

## Logging

API ส่ง log แบบ JSON หนึ่ง event ต่อหนึ่งบรรทัด ตัวอย่างโครงสร้าง:

```json
{
  "timestamp":"2026-09-02T00:00:00Z",
  "level":"INFO",
  "logger":"zyrquen.api",
  "message":"request_complete",
  "event":"request_complete",
  "request_id":"uuid",
  "method":"POST",
  "path":"/api/v1/audit/records",
  "status_code":201,
  "duration_ms":12.34,
  "client_ip":"10.0.0.2"
}
```

ดู log แบบ live และค้นหาเฉพาะ error:

```bash
docker compose -f docker-compose.prod.yml logs -f --tail=100 audit-api
docker compose -f docker-compose.prod.yml logs audit-api | grep '"level":"ERROR"'
```

Compose ตั้งค่า Docker `json-file` log rotation เป็น 10 MB ต่อไฟล์ สูงสุด 5 ไฟล์สำหรับแต่ละ service เพื่อป้องกัน log เต็ม disk หากมีระบบรวม log กลาง ควรส่ง stdout ไปยัง collector เช่น Fluent Bit, Vector หรือระบบที่องค์กรอนุมัติ และตั้ง retention ตามนโยบายข้อมูล

## ความปลอดภัยและการปฏิบัติการ

ควรเปิด Grafana ผ่าน HTTPS และ SSO/reverse proxy หากผู้ใช้ต้องเข้าจากภายนอก ห้ามเปิด port 3000 หรือ 9090 สู่สาธารณะโดยตรง ควรเปลี่ยน Grafana admin password หลังติดตั้ง ตั้งค่า backup ของ named volumes `zyrquen_prometheus_data` และ `zyrquen_grafana_data` และตรวจสอบ disk usage เป็นประจำ

ค่า retention ของ Prometheus ใน Compose ตั้งไว้ 15 วันเพื่อควบคุมการใช้พื้นที่ หากต้องการเก็บนานกว่านี้ควรใช้ remote storage หรือระบบ metrics ที่ออกแบบมาสำหรับ long-term retention แทนการเพิ่ม disk อย่างเดียว
