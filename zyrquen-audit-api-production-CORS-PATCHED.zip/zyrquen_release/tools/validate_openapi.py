import json
from pathlib import Path

schema = json.loads(Path("openapi.json").read_text(encoding="utf-8"))
expected_paths = {
    "/healthz",
    "/metrics",
    "/api/v1/telemetry",
    "/api/v1/audit/records",
    "/api/v1/audit/replay/{seal_id}",
    "/api/v1/audit/report/generate",
    "/api/v1/audit/report/{report_id}/download",
}
assert set(schema["paths"]) == expected_paths
assert schema["openapi"].startswith("3.")
assert "HTTPBearer" in schema.get("components", {}).get("securitySchemes", {})
for path, operations in schema["paths"].items():
    for operation in operations.values():
        if isinstance(operation, dict) and path.startswith("/api/v1/audit/"):
            assert operation.get("security"), f"missing security on {path}"
assert "AuditRecord" in schema["components"]["schemas"]
assert "ReportResponse" in schema["components"]["schemas"]
print(f"OpenAPI validation: OK ({len(schema['paths'])} paths)")
