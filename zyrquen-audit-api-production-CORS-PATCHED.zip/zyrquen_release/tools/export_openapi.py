#!/usr/bin/env python3
"""Export the generated FastAPI OpenAPI document without starting a server."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
os.environ.setdefault("AUDIT_DB_PATH", "/tmp/zyrquen-openapi-audit.db")
os.environ.setdefault("AUDIT_REPORT_DIR", "/tmp/zyrquen-openapi-reports")

from ZYRQUEN_Audit_Trail_API_Chamber17 import app  # noqa: E402

output = Path(os.getenv("OPENAPI_OUTPUT", str(ROOT / "openapi.json")))
output.write_text(json.dumps(app.openapi(), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(f"OpenAPI schema exported to {output}")
