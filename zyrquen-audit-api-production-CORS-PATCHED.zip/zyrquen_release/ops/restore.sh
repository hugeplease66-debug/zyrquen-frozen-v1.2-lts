#!/usr/bin/env bash
set -Eeuo pipefail

BACKUP_DIR="${1:-}"
AUDIT_VOLUME="${AUDIT_VOLUME:-zyrquen_audit_data}"
COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.prod.yml}"
RESTORE_IMAGE="${RESTORE_IMAGE:-python:3.12-slim}"

[[ -n "$BACKUP_DIR" ]] || { echo "Usage: RESTORE_CONFIRM=YES $0 /path/to/backup-directory" >&2; exit 2; }
[[ "$RESTORE_CONFIRM" == "YES" ]] || { echo "Refusing restore: set RESTORE_CONFIRM=YES explicitly" >&2; exit 2; }
[[ -d "$BACKUP_DIR" ]] || { echo "Backup directory not found: $BACKUP_DIR" >&2; exit 1; }
command -v docker >/dev/null 2>&1 || { echo "docker command not found" >&2; exit 127; }

"$(dirname "$0")/verify-backup.sh" "$BACKUP_DIR"

if [[ "${SKIP_COMPOSE_CONTROL:-0}" == "1" ]]; then
  echo "Isolated restore mode: leaving Compose services untouched"
else
  echo "Stopping API before restore"
  docker compose -f "$COMPOSE_FILE" stop audit-api
  trap 'docker compose -f "$COMPOSE_FILE" start audit-api >/dev/null 2>&1 || true' EXIT
fi

echo "Restoring SQLite and reports into Docker volume $AUDIT_VOLUME"
docker run --rm \
  -v "${AUDIT_VOLUME}:/data" \
  -v "$(realpath "$BACKUP_DIR"):/backup:ro" \
  "$RESTORE_IMAGE" python - <<'PY'
import shutil
import tarfile
from pathlib import Path

source = Path('/backup')
target = Path('/data')
shutil.copy2(source / 'audit.db', target / 'audit.db.restore')
(target / 'audit.db.restore').replace(target / 'audit.db')

reports = target / 'reports'
if reports.exists():
    shutil.rmtree(reports)
reports.mkdir(parents=True)
archive = source / 'reports.tar.gz'
if archive.stat().st_size:
    with tarfile.open(archive, 'r:gz') as tar:
        for member in tar.getmembers():
            destination = (target / member.name).resolve()
            if not str(destination).startswith(str(target.resolve()) + '/'):
                raise SystemExit(f'unsafe archive member: {member.name}')
        tar.extractall(target)
PY

echo "Restore completed; starting API"
if [[ "${SKIP_COMPOSE_CONTROL:-0}" != "1" ]]; then
  docker compose -f "$COMPOSE_FILE" start audit-api
  trap - EXIT
fi
