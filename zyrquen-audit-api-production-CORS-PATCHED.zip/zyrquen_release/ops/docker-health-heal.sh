#!/usr/bin/env bash
set -Eeuo pipefail

COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.prod.yml}"
STATE_DIR="${AUTOHEAL_STATE_DIR:-./data/autoheal}"
LOCK_DIR="${AUTOHEAL_LOCK_DIR:-${STATE_DIR}/.lock}"
MAX_RESTARTS="${AUTOHEAL_MAX_RESTARTS:-3}"
WINDOW_SECONDS="${AUTOHEAL_WINDOW_SECONDS:-900}"
SERVICES=(audit-api nginx certbot prometheus grafana)

log_json() {
  local level="$1" event="$2" service="${3:-}" detail="${4:-}"
  printf '{"timestamp":"%s","level":"%s","event":"%s","service":"%s","detail":"%s"}\n' \
    "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$level" "$event" "$service" "$detail"
}

require_docker() {
  command -v docker >/dev/null 2>&1 || { log_json ERROR docker_missing "" "docker command not found"; exit 127; }
  docker compose -f "$COMPOSE_FILE" config --quiet >/dev/null
}

container_id() {
  docker compose -f "$COMPOSE_FILE" ps -q "$1" 2>/dev/null || true
}

status_for() {
  local service="$1" cid
  cid="$(container_id "$service")"
  if [[ -z "$cid" ]]; then
    printf 'missing missing\n'
    return
  fi
  docker inspect -f '{{.State.Status}} {{if .State.Health}}{{.State.Health.Status}}{{else}}none{{end}}' "$cid"
}

is_healthy() {
  local service="$1" status health
  read -r status health < <(status_for "$service")
  [[ "$status" == running && ( "$health" == healthy || "$health" == none || "$health" == starting ) ]]
}

check_all() {
  local failed=0 service status health
  require_docker
  for service in "${SERVICES[@]}"; do
    read -r status health < <(status_for "$service")
    if [[ "$status" == running && ( "$health" == healthy || "$health" == none || "$health" == starting ) ]]; then
      log_json INFO health_ok "$service" "status=${status},health=${health}"
    else
      log_json ERROR health_failed "$service" "status=${status},health=${health}"
      failed=1
    fi
  done
  return "$failed"
}

restart_count() {
  local service="$1" now cutoff count=0 timestamp saved_service
  now="$(date +%s)"
  cutoff=$((now - WINDOW_SECONDS))
  mkdir -p "$STATE_DIR"
  if [[ -f "${STATE_DIR}/restarts.log" ]]; then
    while IFS='|' read -r saved_service timestamp; do
      [[ "$saved_service" == "$service" && "$timestamp" -ge "$cutoff" ]] && count=$((count + 1))
    done < "${STATE_DIR}/restarts.log"
  fi
  printf '%s\n' "$count"
}

record_restart() {
  mkdir -p "$STATE_DIR"
  printf '%s|%s\n' "$1" "$(date +%s)" >> "${STATE_DIR}/restarts.log"
  tail -n 500 "${STATE_DIR}/restarts.log" > "${STATE_DIR}/restarts.log.tmp"
  mv "${STATE_DIR}/restarts.log.tmp" "${STATE_DIR}/restarts.log"
}

heal() {
  local healed=0 service count
  require_docker
  mkdir "$LOCK_DIR" 2>/dev/null || { log_json WARN heal_skipped "" "another auto-heal process is running"; return 0; }
  trap 'rmdir "$LOCK_DIR" 2>/dev/null || true' EXIT

  for service in "${SERVICES[@]}"; do
    if is_healthy "$service"; then
      log_json INFO heal_not_needed "$service" "container is healthy"
      continue
    fi

    count="$(restart_count "$service")"
    if (( count >= MAX_RESTARTS )); then
      log_json CRITICAL circuit_open "$service" "restart limit ${MAX_RESTARTS} reached within ${WINDOW_SECONDS}s; manual intervention required"
      healed=1
      continue
    fi

    log_json WARN restart_attempt "$service" "attempt=$((count + 1))/${MAX_RESTARTS}"
    record_restart "$service"
    docker compose -f "$COMPOSE_FILE" up -d --no-deps "$service" >/dev/null
    sleep 5
    if is_healthy "$service"; then
      log_json INFO restart_success "$service" "service recovered"
    else
      log_json ERROR restart_failed "$service" "service remains unhealthy after restart"
      healed=1
    fi
  done
  return "$healed"
}

watch() {
  local interval="${AUTOHEAL_INTERVAL_SECONDS:-60}"
  while true; do
    heal || true
    sleep "$interval"
  done
}

usage() {
  cat <<'EOF'
Usage: docker-health-heal.sh {check|heal|watch}

Environment:
  COMPOSE_FILE                 Compose file (default: docker-compose.prod.yml)
  AUTOHEAL_STATE_DIR           Restart state directory (default: ./data/autoheal)
  AUTOHEAL_MAX_RESTARTS        Max restarts per service in the window (default: 3)
  AUTOHEAL_WINDOW_SECONDS      Restart window (default: 900)
  AUTOHEAL_INTERVAL_SECONDS    Watch interval (default: 60)
EOF
}

case "${1:-}" in
  check) check_all ;;
  heal) heal ;;
  watch) watch ;;
  *) usage; exit 2 ;;
esac
