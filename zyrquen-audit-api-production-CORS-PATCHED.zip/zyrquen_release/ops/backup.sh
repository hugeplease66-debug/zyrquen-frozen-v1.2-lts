#!/usr/bin/env bash
set -Eeuo pipefail

AUDIT_VOLUME="${AUDIT_VOLUME:-zyrquen_audit_data}"
BACKUP_ROOT="${BACKUP_ROOT:-/var/backups/zyrquen}"
RETENTION_DAYS="${RETENTION_DAYS:-30}"
BACKUP_IMAGE="${BACKUP_IMAGE:-python:3.12-slim}"
LOCK_DIR="${BACKUP_LOCK_DIR:-/run/zyrquen-backup.lock}"

log() { printf '[%s] %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*"; }
fail() { log "ERROR: $*" >&2; exit 1; }

command -v docker >/dev/null 2>&1 || fail "docker command not found"
[[ "$RETENTION_DAYS" =~ ^[0-9]+$ ]] || fail "RETENTION_DAYS must be an integer"
mkdir -p "$BACKUP_ROOT"
mkdir "$LOCK_DIR" 2>/dev/null || fail "another backup is already running"
trap 'rmdir "$LOCK_DIR" 2>/dev/null || true' EXIT

stamp="$(date -u +%Y%m%dT%H%M%SZ)"
tmp_dir="$(mktemp -d "$BACKUP_ROOT/.staging-${stamp}.XXXXXX")"
final_dir="$BACKUP_ROOT/$stamp"
trap 'rm -rf "$tmp_dir"; rmdir "$LOCK_DIR" 2>/dev/null || true' EXIT

log "Creating consistent snapshot from Docker volume $AUDIT_VOLUME"
docker run --rm \
  -e "AUDIT_VOLUME=$AUDIT_VOLUME" \
  -v "${AUDIT_VOLUME}:/data:ro" \
  -v "${tmp_dir}:/backup" \
  "$BACKUP_IMAGE" python - "$stamp" <<'PY'
import hashlib
import json
import os
import shutil
import sqlite3
import sys
import tarfile
from pathlib import Path

stamp = sys.argv[1]
source_db = Path('/data/audit.db')
source_reports = Path('/data/reports')
out = Path('/backup')
if not source_db.is_file():
    raise SystemExit('audit.db does not exist in volume')

# SQLite backup API creates a consistent snapshot while the application is live.
with sqlite3.connect(source_db) as source, sqlite3.connect(out / 'audit.db') as target:
    source.backup(target)
    result = target.execute('PRAGMA integrity_check').fetchone()[0]
    if result != 'ok':
        raise SystemExit(f'SQLite integrity_check failed: {result}')

if source_reports.is_dir():
    with tarfile.open(out / 'reports.tar.gz', 'w:gz') as archive:
        archive.add(source_reports, arcname='reports')
else:
    (out / 'reports.tar.gz').write_bytes(b'')

files = {}
for path in sorted(out.iterdir()):
    if path.name == 'manifest.json':
        continue
    files[path.name] = {
        'bytes': path.stat().st_size,
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    }
manifest = {
    'format': 1,
    'created_at_utc': stamp,
    'source_volume': os.environ.get('AUDIT_VOLUME', 'docker-volume'),
    'sqlite_integrity_check': 'ok',
    'files': files,
}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
PY

mv "$tmp_dir" "$final_dir"
sha256sum "$final_dir"/* > "$final_dir/SHA256SUMS"
find "$BACKUP_ROOT" -mindepth 1 -maxdepth 1 -type d -name '20*' -mtime "+$RETENTION_DAYS" -print -exec rm -rf {} +
log "Backup created: $final_dir"
log "Retention applied: ${RETENTION_DAYS} days"
