#!/usr/bin/env bash
set -Eeuo pipefail

BACKUP_DIR="${1:-}"
[[ -n "$BACKUP_DIR" ]] || { echo "Usage: $0 /path/to/backup-directory" >&2; exit 2; }
[[ -d "$BACKUP_DIR" ]] || { echo "Backup directory not found: $BACKUP_DIR" >&2; exit 1; }

command -v sha256sum >/dev/null 2>&1 || { echo "sha256sum is required" >&2; exit 127; }
[[ -f "$BACKUP_DIR/manifest.json" ]] || { echo "manifest.json is missing" >&2; exit 1; }
[[ -f "$BACKUP_DIR/SHA256SUMS" ]] || { echo "SHA256SUMS is missing" >&2; exit 1; }

(cd "$BACKUP_DIR" && sha256sum -c SHA256SUMS)

python3 - "$BACKUP_DIR" <<'PY'
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

backup = Path(sys.argv[1])
manifest = json.loads((backup / 'manifest.json').read_text(encoding='utf-8'))
if manifest.get('sqlite_integrity_check') != 'ok':
    raise SystemExit('manifest does not report SQLite integrity_check=ok')
for name, expected in manifest.get('files', {}).items():
    path = backup / name
    if not path.is_file():
        raise SystemExit(f'missing backup file: {name}')
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != expected['sha256']:
        raise SystemExit(f'manifest checksum mismatch: {name}')
with sqlite3.connect(backup / 'audit.db') as db:
    result = db.execute('PRAGMA integrity_check').fetchone()[0]
if result != 'ok':
    raise SystemExit(f'SQLite integrity_check failed: {result}')
print(f'Backup verification OK: {backup}')
PY
