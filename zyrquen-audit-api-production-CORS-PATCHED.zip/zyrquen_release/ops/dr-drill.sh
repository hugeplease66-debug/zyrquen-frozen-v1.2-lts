#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DRILL_ROOT="${DRILL_ROOT:-${ROOT_DIR}/data/dr-drills}"
DRILL_IMAGE="${DRILL_IMAGE:-python:3.12-slim}"
DRILL_API_URL="${DRILL_API_URL:-}"
KEEP_DRILL_ARTIFACTS="${KEEP_DRILL_ARTIFACTS:-0}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
VOLUME="zyrquen_drill_${STAMP}_$RANDOM"
BACKUP_ROOT="${DRILL_ROOT}/${STAMP}"
REPORT_FILE="${BACKUP_ROOT}/dr-drill-report.json"

log() { printf '[%s] %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" "$*"; }
fail() { log "ERROR: $*" >&2; exit 1; }
command -v docker >/dev/null 2>&1 || fail "docker command not found"
mkdir -p "$BACKUP_ROOT"

cleanup() {
  if [[ "$KEEP_DRILL_ARTIFACTS" != "1" ]]; then
    docker volume rm -f "$VOLUME" >/dev/null 2>&1 || true
    rm -rf "$BACKUP_ROOT"
  else
    log "Keeping drill artifacts at $BACKUP_ROOT and volume $VOLUME"
  fi
}
trap cleanup EXIT

started="$(date +%s)"
log "Creating isolated volume: $VOLUME"
docker volume create "$VOLUME" >/dev/null

log "Seeding isolated volume with known test data"
docker run --rm -v "${VOLUME}:/data" "$DRILL_IMAGE" python - <<'PY'
import sqlite3
from pathlib import Path

root = Path('/data')
(root / 'reports').mkdir(parents=True, exist_ok=True)
with sqlite3.connect(root / 'audit.db') as db:
    db.execute('CREATE TABLE audit_records (id INTEGER PRIMARY KEY, seal_id INTEGER, details TEXT)')
    db.execute('INSERT INTO audit_records(seal_id, details) VALUES (?, ?)', (14903, 'DR drill seed event'))
    assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
(root / 'reports' / 'dr-drill-report.pdf').write_bytes(b'%PDF-DR-DRILL-TEST%')
PY

log "Creating backup snapshot"
AUDIT_VOLUME="$VOLUME" BACKUP_ROOT="$BACKUP_ROOT/backups" RETENTION_DAYS=999999 \
  "$ROOT_DIR/ops/backup.sh"
BACKUP_DIR="$(find "$BACKUP_ROOT/backups" -mindepth 1 -maxdepth 1 -type d -name '20*' | sort | tail -n 1)"
[[ -n "$BACKUP_DIR" && -d "$BACKUP_DIR" ]] || fail "backup directory was not created"
"$ROOT_DIR/ops/verify-backup.sh" "$BACKUP_DIR"

log "Simulating data loss inside isolated volume"
docker run --rm -v "${VOLUME}:/data" "$DRILL_IMAGE" python - <<'PY'
import shutil
from pathlib import Path
root = Path('/data')
(root / 'audit.db').unlink(missing_ok=True)
shutil.rmtree(root / 'reports', ignore_errors=True)
PY

log "Restoring from verified backup"
RESTORE_CONFIRM=YES SKIP_COMPOSE_CONTROL=1 AUDIT_VOLUME="$VOLUME" \
  "$ROOT_DIR/ops/restore.sh" "$BACKUP_DIR"

log "Verifying restored data"
docker run --rm -v "${VOLUME}:/data:ro" "$DRILL_IMAGE" python - <<'PY'
import sqlite3
from pathlib import Path
root = Path('/data')
db_path = root / 'audit.db'
assert db_path.is_file(), 'audit.db was not restored'
with sqlite3.connect(db_path) as db:
    assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
    row = db.execute('SELECT seal_id, details FROM audit_records WHERE seal_id = 14903').fetchone()
    assert row == (14903, 'DR drill seed event'), row
pdf = root / 'reports' / 'dr-drill-report.pdf'
assert pdf.read_bytes() == b'%PDF-DR-DRILL-TEST%'
print('restored data verification: OK')
PY

api_status="not_configured"
if [[ -n "$DRILL_API_URL" ]]; then
  curl --fail-with-body -fsS "$DRILL_API_URL/healthz" >/dev/null
  api_status="ok"
fi

finished="$(date +%s)"
cat > "$REPORT_FILE" <<EOF
{
  "dr_drill": "PASS",
  "started_at_utc": "${STAMP}",
  "duration_seconds": $((finished - started)),
  "isolated_volume": "${VOLUME}",
  "backup_directory": "${BACKUP_DIR}",
  "sqlite_integrity": "ok",
  "reports_restored": true,
  "api_health_check": "${api_status}",
  "production_volume_touched": false
}
EOF
log "DR Drill PASS"
log "Report: $REPORT_FILE"
