#!/usr/bin/env python3
"""Read-only security audit for the ZYRQUEN Docker/Linux deployment."""
from __future__ import annotations

import json
import os
import re
import shutil
import socket
import stat
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(os.getenv("ZYRQUEN_ROOT", Path(__file__).resolve().parents[1]))
COMPOSE = ROOT / os.getenv("COMPOSE_FILE", "docker-compose.prod.yml")
OUTPUT = Path(os.getenv("SECURITY_AUDIT_OUTPUT", "security-audit-report.json"))
results: list[dict[str, str]] = []


def add(check: str, status: str, detail: str, remediation: str = "") -> None:
    results.append({"check": check, "status": status, "detail": detail, "remediation": remediation})


def run(command: list[str], timeout: int = 10) -> tuple[int, str, str]:
    try:
        proc = subprocess.run(command, capture_output=True, text=True, timeout=timeout, check=False)
        return proc.returncode, proc.stdout.strip(), proc.stderr.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        return 127, "", str(exc)


def check_file_permissions(path: Path, name: str) -> None:
    if not path.exists():
        add(name, "INFO", f"not present: {path}")
        return
    mode = stat.S_IMODE(path.stat().st_mode)
    if mode & 0o077:
        add(name, "FAIL", f"{path} mode={oct(mode)} is accessible by group/other", f"chmod 600 {path}")
    else:
        add(name, "PASS", f"{path} mode={oct(mode)}")


def audit_repository() -> None:
    if COMPOSE.exists():
        text = COMPOSE.read_text(encoding="utf-8", errors="replace")
        for pattern, check, remediation in [
            (r"(?m)^\s*privileged\s*:\s*true", "compose_privileged", "Remove privileged: true."),
            (r"(?m)^\s*network_mode\s*:\s*host", "compose_host_network", "Use an isolated bridge network."),
            (r"/var/run/docker.sock", "compose_docker_socket", "Do not mount the Docker socket into application containers."),
            (r"(?m)^\s*cap_add\s*:", "compose_cap_add", "Drop unnecessary capabilities; prefer cap_drop: ALL."),
        ]:
            if re.search(pattern, text):
                add(check, "FAIL", f"unsafe directive found in {COMPOSE}", remediation)
            else:
                add(check, "PASS", f"unsafe directive not found in {COMPOSE}")
        if re.search(r"(?m)^\s*read_only\s*:\s*true", text) and "no-new-privileges:true" in text:
            add("compose_baseline_hardening", "PASS", "read_only and no-new-privileges are configured")
        else:
            add("compose_baseline_hardening", "WARN", "read_only/no-new-privileges baseline is incomplete", "Enable read_only where compatible and no-new-privileges for services.")
    else:
        add("compose_exists", "FAIL", f"missing {COMPOSE}")

    env = ROOT / ".env"
    check_file_permissions(env, "env_permissions")
    for candidate in ROOT.rglob("*"):
        if candidate.is_file() and candidate.name.lower() in {"id_rsa", "id_ed25519", "server.key", "private.key"}:
            add("private_key_in_project", "FAIL", f"private-key-like filename found: {candidate}", "Move private keys to a secret manager and remove from the project tree.")
    add("secret_scan", "WARN", "manual review required; audit does not print secret values", "Review .env, CI secrets, certificates and registry credentials outside Git history.")


def audit_host() -> None:
    for path, check in [
        ("/proc/sys/net/ipv4/ip_forward", "ip_forward"),
        ("/proc/sys/net/ipv6/conf/all/forwarding", "ipv6_forwarding"),
        ("/proc/sys/kernel/yama/ptrace_scope", "ptrace_scope"),
    ]:
        value = Path(path).read_text().strip() if Path(path).exists() else "unavailable"
        add(check, "INFO", f"value={value}")
    code, output, _ = run(["ufw", "status"])
    if code == 0:
        add("host_firewall", "PASS" if "Status: active" in output else "WARN", output.replace("\n", "; "), "Enable a host firewall and allow only required ports if inactive.")
    else:
        add("host_firewall", "WARN", "ufw is unavailable or status could not be read", "Verify firewall policy with the host security standard.")
    code, output, _ = run(["ss", "-lntup"])
    add("listening_ports", "INFO", output[:4000] if output else "no output", "Review every public listener; expose only 80/443 and required administration ports.")
    code, output, _ = run(["systemctl", "is-enabled", "docker"])
    add("docker_service_enabled", "INFO", output or "docker service not detected")


def audit_docker() -> None:
    if not shutil.which("docker"):
        add("docker_available", "INFO", "docker CLI is not available in this environment")
        return
    code, output, error = run(["docker", "info", "--format", "{{json .SecurityOptions}}"])
    if code == 0:
        add("docker_security_options", "INFO", output)
    else:
        add("docker_access", "WARN", error or "docker info failed", "Run the audit on the Docker host with a read-only audit account where possible.")
        return
    code, output, _ = run(["docker", "ps", "--format", "{{.ID}} {{.Names}}"])
    if code != 0:
        return
    for line in output.splitlines():
        container_id, _, name = line.partition(" ")
        code, inspect, _ = run(["docker", "inspect", container_id])
        if code != 0:
            continue
        try:
            data = json.loads(inspect)[0]
            host = data.get("HostConfig", {})
            config = data.get("Config", {})
            if host.get("Privileged"):
                add("container_privileged", "FAIL", name, "Recreate without privileged mode.")
            if host.get("NetworkMode") == "host":
                add("container_host_network", "FAIL", name, "Use an isolated network.")
            mounts = [m.get("Source", "") for m in host.get("Mounts", [])]
            if "/var/run/docker.sock" in mounts:
                add("container_docker_socket", "FAIL", name, "Remove Docker socket mount.")
            user = config.get("User", "")
            add("container_user", "PASS" if user and user not in {"0", "root"} else "WARN", f"{name}: user={user or 'default'}", "Run as a non-root UID.")
        except (json.JSONDecodeError, IndexError):
            add("container_inspect", "WARN", f"could not parse docker inspect for {name}")


def main() -> int:
    audit_repository()
    audit_host()
    audit_docker()
    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "project_root": str(ROOT),
        "compose_file": str(COMPOSE),
        "read_only": True,
        "summary": {status: sum(item["status"] == status for item in results) for status in ("PASS", "WARN", "FAIL", "INFO")},
        "checks": results,
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report["summary"], sort_keys=True))
    print(f"Report: {OUTPUT}")
    return 1 if report["summary"]["FAIL"] else 0


if __name__ == "__main__":
    sys.exit(main())
