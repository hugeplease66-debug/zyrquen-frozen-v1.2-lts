#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="${ZYRQUEN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
SYSCTL_FILE="${SYSCTL_FILE:-/etc/sysctl.d/99-zyrquen-hardening.conf}"

usage() {
  cat <<'EOF'
Usage: harden_host.sh check|apply

check: run read-only security audit
apply: apply project permission hardening and install a reviewed sysctl fragment

Safety:
  apply requires root and HARDEN_CONFIRM=YES.
  APPLY_SYSCTL=YES is additionally required before loading sysctl values.
EOF
}

if [[ "${1:-}" == "check" ]]; then
  exec python3 "$ROOT_DIR/ops/security_audit.py"
fi

[[ "${1:-}" == "apply" ]] || { usage; exit 2; }
[[ "$EUID" -eq 0 ]] || { echo "apply must run as root" >&2; exit 1; }
[[ "${HARDEN_CONFIRM:-}" == "YES" ]] || { echo "Refusing changes: set HARDEN_CONFIRM=YES" >&2; exit 2; }

backup_dir="/var/backups/zyrquen-host-hardening/$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$backup_dir"

if [[ -f "$ROOT_DIR/.env" ]]; then
  cp -a "$ROOT_DIR/.env" "$backup_dir/env.before"
  chmod 600 "$ROOT_DIR/.env"
fi
if [[ -d "$ROOT_DIR/data" ]]; then
  chmod 700 "$ROOT_DIR/data"
fi
find "$ROOT_DIR/ops" -maxdepth 1 -type f -name '*.sh' -exec chmod 750 {} +

if [[ -e "$SYSCTL_FILE" ]]; then
  cp -a "$SYSCTL_FILE" "$backup_dir/$(basename "$SYSCTL_FILE").before"
fi
install -d -m 755 "$(dirname "$SYSCTL_FILE")"
cat > "$SYSCTL_FILE" <<'EOF'
# Review with the host security owner before applying.
# These settings reduce common Linux network/kernel attack surface.
net.ipv4.conf.all.rp_filter=1
net.ipv4.conf.default.rp_filter=1
net.ipv4.icmp_echo_ignore_broadcasts=1
fs.protected_hardlinks=1
fs.protected_symlinks=1
EOF
chmod 644 "$SYSCTL_FILE"

if [[ "${APPLY_SYSCTL:-NO}" == "YES" ]]; then
  sysctl --system >/dev/null
  echo "Applied sysctl settings from $SYSCTL_FILE"
else
  echo "Installed sysctl fragment but did not load it. Review it, then run with APPLY_SYSCTL=YES if approved."
fi

echo "Hardening applied; previous files are under $backup_dir"
