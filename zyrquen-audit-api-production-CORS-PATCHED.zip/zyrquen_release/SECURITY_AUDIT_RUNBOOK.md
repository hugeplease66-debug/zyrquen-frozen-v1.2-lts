# Security Audit and Hardening Runbook

## ขอบเขต

`ops/security_audit.py` เป็นการตรวจแบบ read-only สำหรับ project tree, Linux host, Docker runtime และ production Compose โดยสร้าง JSON report และไม่ restart container, ไม่แก้ไฟล์ host, ไม่อ่านค่า secret มาแสดง และไม่ลบข้อมูล

ตรวจหลัก ๆ ได้แก่ privileged mode, host network, Docker socket mount, container user, read-only/no-new-privileges, listening ports, firewall status, kernel/network settings, `.env` permissions, private-key-like files และความสามารถในการเข้าถึง Docker runtime

ผล `FAIL` หมายถึงควรแก้ก่อน production; `WARN` หมายถึงต้อง review ตาม policy ขององค์กร; `INFO` เป็นข้อมูลประกอบ ไม่ใช่ผลผ่านด้านความปลอดภัย

## รัน read-only audit

```bash
cd /opt/zyrquen
python3 ops/security_audit.py
```

กำหนด output และ project path:

```bash
ZYRQUEN_ROOT=/opt/zyrquen \
SECURITY_AUDIT_OUTPUT=/var/log/zyrquen/security-audit.json \
python3 ops/security_audit.py
```

ดูสรุปจาก report:

```bash
python3 -c 'import json; print(json.load(open("security-audit-report.json"))["summary"])'
```

ควรรันบน Docker host จริงด้วย account ที่อ่าน Docker metadata ได้ แต่ควรจำกัดสิทธิ์และเก็บ report ตามนโยบายข้อมูล

## Hardening ที่ opt-in

`ops/harden_host.sh check` เรียก read-only audit ส่วน `apply` จะไม่ทำงานจนกว่าจะกำหนด confirmation อย่างชัดเจน:

```bash
./ops/harden_host.sh check
sudo HARDEN_CONFIRM=YES ./ops/harden_host.sh apply
```

โหมด apply จะ backup `.env` ก่อนปรับเป็น mode 600, ปรับ `data/` เป็น mode 700, จำกัด script mode และติดตั้ง sysctl fragment ไปที่ `/etc/sysctl.d/99-zyrquen-hardening.conf` แต่จะ **ไม่ load sysctl โดยอัตโนมัติ**

หลัง review โดยผู้ดูแล host จึงค่อย apply sysctl:

```bash
sudo HARDEN_CONFIRM=YES APPLY_SYSCTL=YES ./ops/harden_host.sh apply
```

อย่าใช้ apply ใน production โดยไม่ตรวจผลกระทบกับ network policy, routing, SSH, container runtime และ change-management approval ก่อน สคริปต์เก็บไฟล์ก่อนแก้ไว้ใต้ `/var/backups/zyrquen-host-hardening/`

## Docker daemon configuration

`deploy/docker/daemon.json.example` เป็นตัวอย่างสำหรับ review/merge กับ `/etc/docker/daemon.json` เท่านั้น ห้ามคัดลอกทับไฟล์เดิมโดยไม่ merge ค่า configuration ที่ใช้อยู่ และควรตรวจ `docker info` หลัง restart daemon

ค่าที่แนะนำประกอบด้วย live restore, จำกัด log rotation, ปิด inter-container communication ตามความเหมาะสม และปิด userland proxy หากไม่กระทบระบบ

## Remediation priority

| Priority | ประเด็น | แนวทาง |
|---|---|---|
| Critical | privileged container, host network, Docker socket, public admin ports | หยุดการเปิดใช้งานและแก้ Compose/host policy ก่อน |
| High | root container, `.env` เปิดกว้าง, firewall inactive, private key ใน project tree | แก้ permission/secret management และจำกัด network |
| Medium | kernel settings หรือ log retention ไม่ตรง policy | review กับ host/security owner แล้วปรับผ่าน change process |
| Review | INFO/WARN จาก environment ที่ตรวจไม่ได้ | เก็บหลักฐานและประเมินตาม baseline ขององค์กร |

## สิ่งที่ audit ไม่รับรอง

สคริปต์นี้ไม่ใช่ vulnerability scanner แบบ CVE database, ไม่รับรอง compliance, ไม่ทดสอบ penetration, ไม่ตรวจ application business logic และไม่รับรองความปลอดภัยของ image หากต้องการ image vulnerability scan ให้ผนวก Trivy/Grype ใน CI/CD ตามนโยบายองค์กรและ pin เวอร์ชันของ scanner

ห้ามเผยแพร่ JSON report ต่อสาธารณะ เพราะอาจมีข้อมูลเกี่ยวกับชื่อไฟล์, network listeners และ Docker topology แม้สคริปต์จะไม่แสดง secret values
