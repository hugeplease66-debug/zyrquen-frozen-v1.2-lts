# Docker Health Check and Auto-healing Runbook

## ภาพรวม

สคริปต์ `ops/docker-health-heal.sh` ตรวจสอบ container ทั้ง 5 services ใน `docker-compose.prod.yml`: `audit-api`, `nginx`, `certbot`, `prometheus` และ `grafana` โดยอ่านสถานะจาก Docker health status และสามารถเริ่ม service ที่หยุดหรือ unhealthy ใหม่ได้

สคริปต์มีคำสั่ง 3 แบบ:

| คำสั่ง | หน้าที่ |
|---|---|
| `check` | ตรวจทุก service แบบ read-only และคืน exit code `1` หากมี service ผิดปกติ |
| `heal` | ตรวจและ restart เฉพาะ service ที่ผิดปกติหนึ่งรอบ |
| `watch` | วนตรวจและ heal ต่อเนื่องตาม interval ที่กำหนด |

การใช้งาน production ที่แนะนำคือใช้ `systemd timer` บน host ทุก 60 วินาที แทนการรัน auto-healing container ที่ต้อง mount Docker socket เพราะลด attack surface และแยกสิทธิ์ควบคุม Docker ไว้ที่ host

## ตรวจสอบด้วยตนเอง

```bash
cd /opt/zyrquen
chmod +x ops/docker-health-heal.sh
./ops/docker-health-heal.sh check
./ops/docker-health-heal.sh heal
```

ผลลัพธ์เป็น JSON line เช่น:

```json
{"timestamp":"2026-09-02T00:00:00Z","level":"INFO","event":"health_ok","service":"audit-api","detail":"status=running,health=healthy"}
```

## ติดตั้ง systemd timer

สมมติว่า project อยู่ที่ `/opt/zyrquen`:

```bash
sudo install -m 0755 ops/docker-health-heal.sh /opt/zyrquen/ops/docker-health-heal.sh
sudo install -m 0644 ops/docker-health-heal.service /etc/systemd/system/
sudo install -m 0644 ops/docker-health-heal.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now docker-health-heal.timer
sudo systemctl status docker-health-heal.timer
```

ดูผลการทำงานล่าสุด:

```bash
sudo systemctl start docker-health-heal.service
sudo journalctl -u docker-health-heal.service -n 100 --no-pager
```

ไฟล์ service ทำงานด้วย `root` เพราะต้องสั่ง Docker Compose และตรวจ Docker container หากองค์กรใช้ rootless Docker ให้เปลี่ยน `User` และ `WorkingDirectory` ให้ตรงกับ account ที่เป็นเจ้าของ Docker daemon

## Circuit breaker และ backoff

เพื่อป้องกัน restart loop สคริปต์จะเก็บเวลาการ restart ไว้ใน `./data/autoheal/restarts.log` โดยค่าเริ่มต้นอนุญาตให้ restart service เดิมได้สูงสุด 3 ครั้งภายใน 900 วินาที หากเกิน limit จะเปิด circuit breaker, ไม่ restart ต่อ และคืนเหตุการณ์ `circuit_open` เพื่อให้ผู้ดูแลเข้าตรวจสอบเอง

ปรับค่าได้ด้วย environment variables:

```bash
AUTOHEAL_MAX_RESTARTS=3 \
AUTOHEAL_WINDOW_SECONDS=900 \
./ops/docker-health-heal.sh heal
```

กำหนด Compose file หรือ state path อื่น:

```bash
COMPOSE_FILE=docker-compose.prod.yml \
AUTOHEAL_STATE_DIR=/var/lib/zyrquen-autoheal \
./ops/docker-health-heal.sh check
```

## พฤติกรรมที่ควรรู้

`certbot` ไม่มี container healthcheck แบบ HTTP เพราะเป็น renewal worker จึงถือว่า container ที่อยู่ในสถานะ `running` และไม่มี health field เป็นปกติ ส่วน API, Nginx, Prometheus และ Grafana มี healthcheck ใน Compose อยู่แล้ว

การ restart service จะใช้ `docker compose up -d --no-deps <service>` เพื่อไม่ restart dependency ทั้ง stack สคริปต์ไม่ลบ volume, ไม่ทำ `down`, ไม่ rebuild image และไม่เปลี่ยน configuration อัตโนมัติ

หาก service ยัง unhealthy หลัง restart สคริปต์จะบันทึก `restart_failed` และไม่พยายามวน restart ทันทีเกินวงจรที่กำหนด ผู้ดูแลควรตรวจ logs และ Docker events:

```bash
docker compose -f docker-compose.prod.yml ps
docker compose -f docker-compose.prod.yml logs --tail=200 audit-api nginx prometheus grafana
docker events --since 10m
```

## ข้อควรระวังด้านความปลอดภัย

อย่าเปิดสคริปต์ให้ผู้ใช้ทั่วไปเรียกได้ เพราะผู้ที่เรียกได้จะมีความสามารถควบคุม Docker ทางอ้อม อย่า mount `/var/run/docker.sock` เข้า container auto-healing หากไม่จำเป็น และควรจำกัดสิทธิ์ไฟล์ state directory ไม่ให้ผู้ใช้ทั่วไปแก้ไข restart log เพื่อหลีกเลี่ยงการหลบ circuit breaker

Auto-healing ไม่แทน root-cause analysis, monitoring alert หรือ backup ควรใช้ Prometheus alerts และ external monitoring ร่วมกัน และควรมี runbook สำหรับ database corruption, disk full, certificate renewal failure และ image rollback
