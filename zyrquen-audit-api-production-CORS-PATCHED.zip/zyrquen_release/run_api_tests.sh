#!/usr/bin/env bash
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

PYTHON_BIN="${PYTHON_BIN:-python3}"
"$PYTHON_BIN" -m pip install -q -r requirements-audit-api.txt
PYTHONPATH="$ROOT_DIR" "$PYTHON_BIN" -m pytest -q tests/ test_audit_api.py
