import importlib

from fastapi.testclient import TestClient


def make_client(tmp_path, monkeypatch):
    monkeypatch.setenv("ZYRQUEN_API_KEY", "test-secret-key")
    monkeypatch.setenv("AUDIT_DB_PATH", str(tmp_path / "audit.db"))
    monkeypatch.setenv("AUDIT_REPORT_DIR", str(tmp_path / "reports"))
    module = importlib.import_module("ZYRQUEN_Audit_Trail_API_Chamber17")
    module = importlib.reload(module)
    client = TestClient(module.app)
    client.__enter__()
    return client, module


def test_health_and_telemetry_are_available(tmp_path, monkeypatch):
    client, _ = make_client(tmp_path, monkeypatch)
    assert client.get("/healthz").status_code == 200
    telemetry = client.get("/api/v1/telemetry").json()
    assert telemetry["status"] == "operational"
    assert telemetry["canonical_seals_count"] == 0
    client.__exit__(None, None, None)


def test_authentication_rejects_missing_and_fake_keys(tmp_path, monkeypatch):
    client, _ = make_client(tmp_path, monkeypatch)
    payload = {"chamber": "A", "module": "M", "event_type": "E", "details": "D"}
    assert client.post("/api/v1/audit/records", json=payload).status_code == 401
    assert client.post("/api/v1/audit/records", json=payload, headers={"Authorization": "Bearer EP-SOVEREIGN-01"}).status_code == 403
    client.__exit__(None, None, None)


def test_record_persists_and_replay_finds_it(tmp_path, monkeypatch):
    client, _ = make_client(tmp_path, monkeypatch)
    headers = {"Authorization": "Bearer test-secret-key"}
    payload = {"seal_id": 14903, "chamber": "CH-1", "module": "audit", "event_type": "CREATE", "details": "hello"}
    created = client.post("/api/v1/audit/records", json=payload, headers=headers)
    assert created.status_code == 201
    record = created.json()
    assert len(record["record_hash"]) == 64
    listed = client.get("/api/v1/audit/records", headers=headers).json()
    assert listed[0]["record_id"] == record["record_id"]
    replay = client.post("/api/v1/audit/replay/14903", headers=headers)
    assert replay.status_code == 200
    assert record["record_id"] in replay.json()["matching_record_ids"]
    client.__exit__(None, None, None)


def test_invalid_record_and_unknown_replay_are_rejected(tmp_path, monkeypatch):
    client, _ = make_client(tmp_path, monkeypatch)
    headers = {"Authorization": "Bearer test-secret-key"}
    invalid = {"seal_id": -1, "chamber": "A", "module": "M", "event_type": "E", "details": "D"}
    assert client.post("/api/v1/audit/records", json=invalid, headers=headers).status_code == 422
    assert client.post("/api/v1/audit/replay/14903", headers=headers).status_code == 404
    client.__exit__(None, None, None)


def test_report_is_created_and_downloadable(tmp_path, monkeypatch):
    client, _ = make_client(tmp_path, monkeypatch)
    headers = {"Authorization": "Bearer test-secret-key"}
    response = client.post("/api/v1/audit/report/generate", json={}, headers=headers)
    assert response.status_code == 201
    report = response.json()
    download = client.get(report["download_url"], headers=headers)
    assert download.status_code == 200
    assert download.headers["content-type"] == "application/pdf"
    assert download.content.startswith(b"%PDF")
    client.__exit__(None, None, None)
