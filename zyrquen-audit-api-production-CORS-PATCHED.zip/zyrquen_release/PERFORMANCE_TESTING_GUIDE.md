# API Contract และ Performance Testing Guide

## ขอบเขต

ชุดนี้แบ่งเป็นสองส่วน ได้แก่ contract tests ที่ตรวจว่า runtime responses สอดคล้องกับ generated OpenAPI schema และ Locust load profile ที่ยิง endpoint สำคัญทุกกลุ่มด้วย synthetic data

Load test ต้องรันบน staging หรือ isolated environment เป็นค่าเริ่มต้น ห้ามยิง production โดยไม่มี change approval, maintenance window และ target ที่ยืนยันแล้ว สคริปต์จะหยุดทันทีหากไม่ได้ตั้ง `LOAD_TEST_CONFIRM=YES`, ไม่มี `TARGET_URL` หรือไม่มี `LOAD_TEST_API_KEY` และจะปฏิเสธ hostname ที่มีคำว่า `prod`, `production` หรือ `live` เว้นแต่ตั้ง `ALLOW_PRODUCTION_LOAD_TEST=YES` อย่างชัดเจน

## Contract testing

Contract test ใช้ generated OpenAPI schema และเรียก FastAPI app ผ่าน TestClient เพื่อตรวจ status code, response fields, `$ref` schemas, security scheme และความครบถ้วนของ runtime paths:

```bash
python3 -m pip install -r requirements-audit-api.txt
python3 -m pytest -q tests/test_openapi_contract.py
```

Export และตรวจ schema ใหม่หลังแก้ endpoint/model:

```bash
python3 tools/export_openapi.py
python3 tools/validate_openapi.py
```

หากแก้ request/response model ต้องปรับตัวอย่างใน `API_DOCUMENTATION.md`, tests และ `openapi.json` พร้อมกัน

## Locust load test

ติดตั้ง dependency แยกจาก runtime image:

```bash
python3 -m pip install -r requirements-performance.txt
```

รัน smoke load บน staging:

```bash
LOAD_TEST_CONFIRM=YES \
TARGET_URL=https://staging-api.example.com \
LOAD_TEST_API_KEY="$STAGING_API_KEY" \
USERS=5 SPAWN_RATE=1 RUN_TIME=30s \
./performance/run_load_test.sh
```

รัน baseline ที่ยาวขึ้น:

```bash
LOAD_TEST_CONFIRM=YES \
TARGET_URL=https://staging-api.example.com \
LOAD_TEST_API_KEY="$STAGING_API_KEY" \
USERS=50 SPAWN_RATE=5 RUN_TIME=10m \
LOCUST_HTML_REPORT=artifacts/staging-baseline.html \
LOCUST_CSV_PREFIX=artifacts/staging-baseline \
./performance/run_load_test.sh
```

หากต้องการใช้ Locust UI แทน headless runner:

```bash
locust -f performance/locustfile.py --host https://staging-api.example.com
```

ใน UI ให้กำหนด users และ spawn rate อย่างค่อยเป็นค่อยไป และอย่าใช้ API key production ใน load test fixture

## Scenarios ที่ครอบคลุม

| Scenario | Endpoint |
|---|---|
| Liveness | `GET /healthz` |
| Telemetry | `GET /api/v1/telemetry` |
| Metrics | `GET /metrics` |
| List | `GET /api/v1/audit/records` |
| Write | `POST /api/v1/audit/records` |
| Replay | `POST /api/v1/audit/replay/{seal_id}` |
| Report lifecycle | `POST /api/v1/audit/report/generate` และ `GET /api/v1/audit/report/{report_id}/download` |

ข้อมูลที่สร้างโดย Locust ใช้ chamber `LOAD-TEST` และ details ที่ระบุว่าเป็น synthetic data ควรลบหรือแยก database หลังการทดสอบตาม data-retention policy

## เกณฑ์ประเมินเบื้องต้น

| Metric | Baseline ที่แนะนำให้เริ่มวัด |
|---|---:|
| Error rate | < 1% ใน staging load profile |
| p95 `/healthz` | < 200 ms |
| p95 read endpoints | < 500 ms |
| p95 write/report endpoints | กำหนดจากผล baseline และ report size |
| Failed requests | 0 สำหรับ contract-critical scenarios |
| CPU/memory | ต้องไม่ถึง sustained saturation |
| SQLite | ห้ามมี `database is locked` หรือ integrity error |

ค่าเหล่านี้เป็น starting thresholds ไม่ใช่ SLA ต้องปรับตาม hardware, network, database engine และ target traffic จริง

## Safety และผลกระทบ

ไม่ควรรัน load test พร้อมกับ DR drill, restore, backup หรือ deployment ใน environment เดียวกัน เว้นแต่กำลังทดสอบ failure scenario โดยตั้งใจ ควรใช้ test API key, isolated database, bounded duration และบันทึก test window ทุกครั้ง ห้ามใส่ API key ใน command history หาก shell history อยู่ใน shared host; ใช้ protected environment variable หรือ secret injection แทน

ผลลัพธ์ Locust ได้แก่ HTML report และ CSV files ควรเก็บเป็น test artifact ที่จำกัดสิทธิ์ เพราะอาจมี endpoint names, timings และ error details
