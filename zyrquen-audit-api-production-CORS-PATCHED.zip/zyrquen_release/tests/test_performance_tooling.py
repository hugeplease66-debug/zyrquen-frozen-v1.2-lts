import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_load_runner_requires_explicit_confirmation_and_key():
    script = ROOT / "performance" / "run_load_test.sh"
    result = subprocess.run(["bash", "-n", str(script)], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    text = script.read_text(encoding="utf-8")
    assert 'LOAD_TEST_CONFIRM' in text
    assert 'LOAD_TEST_API_KEY' in text
    assert 'ALLOW_PRODUCTION_LOAD_TEST' in text
    assert '--headless' in text


def test_locust_profile_covers_important_endpoints():
    text = (ROOT / "performance" / "locustfile.py").read_text(encoding="utf-8")
    for endpoint in (
        "/healthz",
        "/api/v1/telemetry",
        "/metrics",
        "/api/v1/audit/records",
        "/api/v1/audit/replay/",
        "/api/v1/audit/report/generate",
        "/api/v1/audit/report/",
    ):
        assert endpoint in text
    assert "LOAD-TEST" in text
    assert "load-test-only-key" in text
