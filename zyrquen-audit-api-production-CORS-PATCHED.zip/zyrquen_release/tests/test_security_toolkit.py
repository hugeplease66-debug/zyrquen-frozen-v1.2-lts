import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_security_audit_is_read_only_by_contract():
    script = ROOT / "ops" / "security_audit.py"
    result = subprocess.run(["python3", "-m", "py_compile", str(script)], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    text = script.read_text(encoding="utf-8")
    assert '"read_only": True' in text
    assert "docker inspect" in text
    assert "secret values" in text


def test_hardening_requires_explicit_confirmation():
    script = ROOT / "ops" / "harden_host.sh"
    result = subprocess.run(["bash", "-n", str(script)], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    text = script.read_text(encoding="utf-8")
    assert 'HARDEN_CONFIRM:-' in text
    assert 'HARDEN_CONFIRM=YES' in text
    assert 'APPLY_SYSCTL=YES' in text


def test_security_audit_does_not_contain_destructive_commands():
    text = (ROOT / "ops" / "security_audit.py").read_text(encoding="utf-8")
    assert "docker rm" not in text
    assert "docker system prune" not in text
    assert "os.remove" not in text
