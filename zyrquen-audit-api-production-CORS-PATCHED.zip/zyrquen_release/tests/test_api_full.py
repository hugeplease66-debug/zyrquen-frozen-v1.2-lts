import importlib
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


@pytest.fixture
def api(tmp_path, monkeypatch):
    monkeypatch.setenv("ZYRQUEN_API_KEY", "test-secret-key")
    monkeypatch.setenv("AUDIT_DB_PATH", str(tmp_path / "audit.db"))
    monkeypatch.setenv("AUDIT_REPORT_DIR", str(tmp_path / "reports"))
    module = importlib.import_module("ZYRQUEN_Audit_Trail_API_Chamber17")
    module = importlib.reload(module)
    with TestClient(module.app) as client:
        yield client


@pytest.fixture
def auth_headers():
    return {"Authorization": "Bearer test-secret-key"}


def record_payload(seal_id=14903, chamber="CH-1", event_type="CREATE"):
    return {
        "seal_id": seal_id,
        "chamber": chamber,
        "module": "audit",
        "event_type": event_type,
        "details": "automated test event",
        "legal_sections": [28, 9, 9],
        "forensic_ready": True,
    }


def test_lifespan_initializes_database(api):
    response = api.get("/metrics")
    assert response.status_code == 200
    assert "zyrquen_audit_records_stored" in response.text


def test_healthz_contract(api):
    response = api.get("/healthz")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "version": "2.0.0"}


def test_metrics_endpoint_exposes_prometheus_data(api):
    response = api.get("/metrics", headers={"X-Request-ID": "metrics-test-id"})
    assert response.status_code == 200
    assert "zyrquen_http_requests_total" in response.text
    assert "zyrquen_http_request_duration_seconds" in response.text
    assert response.headers["X-Request-ID"] == "metrics-test-id"


def test_telemetry_contract_and_count(api):
    response = api.get("/api/v1/telemetry")
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "operational"
    assert body["block_height"] == 849202
    assert body["canonical_seals_count"] == 0
    assert len(body["genesis_hash"]) == 64
    assert isinstance(body["generated_at"], float)


def test_all_protected_endpoints_require_bearer_auth(api):
    protected = [
        ("post", "/api/v1/audit/records", record_payload()),
        ("get", "/api/v1/audit/records", None),
        ("post", "/api/v1/audit/replay/14903", None),
        ("post", "/api/v1/audit/report/generate", {}),
        ("get", "/api/v1/audit/report/not-real/download", None),
    ]
    for method, path, body in protected:
        response = getattr(api, method)(path, json=body) if body is not None else getattr(api, method)(path)
        assert response.status_code == 401, (method, path, response.text)


def test_fake_or_old_mock_tokens_are_rejected(api):
    headers = {"Authorization": "Bearer EP-SOVEREIGN-01"}
    response = api.get("/api/v1/audit/records", headers=headers)
    assert response.status_code == 403


def test_create_record_normalizes_sections_and_creates_hash(api, auth_headers):
    response = api.post("/api/v1/audit/records", json=record_payload(), headers=auth_headers)
    assert response.status_code == 201
    body = response.json()
    assert body["legal_sections"] == [9, 28]
    assert body["forensic_ready"] is True
    assert len(body["record_id"]) > 10
    assert len(body["record_hash"]) == 64
    assert body["previous_hash"] == "909ab814479844d8a14816bed34cdbb07528e18501da86fc4691763a43fa4c68"


def test_hash_chain_and_persistence(api, auth_headers):
    first = api.post("/api/v1/audit/records", json=record_payload(event_type="FIRST"), headers=auth_headers).json()
    second = api.post("/api/v1/audit/records", json=record_payload(event_type="SECOND"), headers=auth_headers).json()
    assert second["previous_hash"] == first["record_hash"]
    listed = api.get("/api/v1/audit/records?limit=1&offset=0", headers=auth_headers)
    assert listed.status_code == 200
    assert len(listed.json()) == 1
    assert listed.json()[0]["record_id"] == second["record_id"]


def test_record_filter_and_pagination(api, auth_headers):
    api.post("/api/v1/audit/records", json=record_payload(chamber="CH-A"), headers=auth_headers)
    api.post("/api/v1/audit/records", json=record_payload(chamber="CH-B"), headers=auth_headers)
    response = api.get("/api/v1/audit/records?chamber=CH-A", headers=auth_headers)
    assert response.status_code == 200
    assert len(response.json()) == 1
    assert response.json()[0]["chamber"] == "CH-A"


def test_invalid_record_payload_is_rejected(api, auth_headers):
    invalid = record_payload(seal_id=-1)
    invalid["details"] = ""
    response = api.post("/api/v1/audit/records", json=invalid, headers=auth_headers)
    assert response.status_code == 422


def test_query_bounds_are_enforced(api, auth_headers):
    assert api.get("/api/v1/audit/records?limit=0", headers=auth_headers).status_code == 422
    assert api.get("/api/v1/audit/records?limit=501", headers=auth_headers).status_code == 422
    assert api.get("/api/v1/audit/records?offset=-1", headers=auth_headers).status_code == 422


def test_replay_requires_stored_seal_and_returns_matching_ids(api, auth_headers):
    created = api.post("/api/v1/audit/records", json=record_payload(14903), headers=auth_headers).json()
    response = api.post("/api/v1/audit/replay/14903", headers=auth_headers)
    assert response.status_code == 200
    body = response.json()
    assert body["status"] == "REPLAY_COMPLETE"
    assert body["matching_record_ids"] == [created["record_id"]]
    assert body["stages_executed"] == [f"STAGE-{i:02d}" for i in range(1, 13)]


def test_replay_unknown_and_out_of_range_seals_fail(api, auth_headers):
    assert api.post("/api/v1/audit/replay/14903", headers=auth_headers).status_code == 404
    assert api.post("/api/v1/audit/replay/-1", headers=auth_headers).status_code == 422
    assert api.post("/api/v1/audit/replay/10000001", headers=auth_headers).status_code == 422


def test_report_validation_creation_and_download(api, auth_headers):
    wrong_block = api.post(
        "/api/v1/audit/report/generate",
        json={"block_height": 1},
        headers=auth_headers,
    )
    assert wrong_block.status_code == 400

    created = api.post("/api/v1/audit/report/generate", json={}, headers=auth_headers)
    assert created.status_code == 201
    body = created.json()
    assert body["file_name"].endswith(".pdf")
    assert len(body["sha256"]) == 64

    downloaded = api.get(body["download_url"], headers=auth_headers)
    assert downloaded.status_code == 200
    assert downloaded.headers["content-type"] == "application/pdf"
    assert downloaded.content.startswith(b"%PDF")


def test_report_not_found_is_404(api, auth_headers):
    response = api.get("/api/v1/audit/report/ZYR-AUD-NOTFOUND/download", headers=auth_headers)
    assert response.status_code == 404


def test_openapi_and_docs_are_available(api):
    assert api.get("/openapi.json").status_code == 200
    assert api.get("/docs").status_code == 200
