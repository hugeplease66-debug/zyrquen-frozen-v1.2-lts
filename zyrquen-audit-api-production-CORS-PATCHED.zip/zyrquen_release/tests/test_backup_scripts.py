import hashlib
import json
import sqlite3
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
VERIFY = ROOT / "ops" / "verify-backup.sh"


def create_backup(path: Path) -> None:
    db_path = path / "audit.db"
    with sqlite3.connect(db_path) as db:
        db.execute("CREATE TABLE audit_records (id INTEGER PRIMARY KEY, details TEXT)")
        db.execute("INSERT INTO audit_records(details) VALUES ('test')")
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
    (path / "reports.tar.gz").write_bytes(b"test-reports")
    manifest_files = {}
    for file in sorted(path.iterdir()):
        manifest_files[file.name] = {
            "bytes": file.stat().st_size,
            "sha256": hashlib.sha256(file.read_bytes()).hexdigest(),
        }
    (path / "manifest.json").write_text(
        json.dumps({"format": 1, "sqlite_integrity_check": "ok", "files": manifest_files})
    )
    subprocess.run(
        f"cd {path} && sha256sum audit.db reports.tar.gz manifest.json > SHA256SUMS",
        shell=True,
        check=True,
    )


def test_verify_backup_accepts_valid_snapshot(tmp_path):
    backup = tmp_path / "backup"
    backup.mkdir()
    create_backup(backup)
    result = subprocess.run([str(VERIFY), str(backup)], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    assert "Backup verification OK" in result.stdout


def test_verify_backup_rejects_tampered_database(tmp_path):
    backup = tmp_path / "backup"
    backup.mkdir()
    create_backup(backup)
    with (backup / "audit.db").open("ab") as stream:
        stream.write(b"tampered")
    result = subprocess.run([str(VERIFY), str(backup)], capture_output=True, text=True)
    assert result.returncode != 0
