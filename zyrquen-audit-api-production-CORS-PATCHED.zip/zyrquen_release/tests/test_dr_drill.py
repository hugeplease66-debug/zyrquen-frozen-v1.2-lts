import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_dr_drill_script_is_valid_and_guarded():
    script = ROOT / "ops" / "dr-drill.sh"
    result = subprocess.run(["bash", "-n", str(script)], capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    text = script.read_text(encoding="utf-8")
    assert "zyrquen_drill_" in text
    assert "docker volume create" in text
    assert '"production_volume_touched": false' in text
    assert "SKIP_COMPOSE_CONTROL=1" in text
    assert "docker volume rm -f" in text


def test_restore_requires_explicit_confirmation():
    text = (ROOT / "ops" / "restore.sh").read_text(encoding="utf-8")
    assert 'RESTORE_CONFIRM' in text
    assert '== "YES"' in text
    assert "SKIP_COMPOSE_CONTROL" in text
