import importlib
import json
import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient
from jsonschema import RefResolver, validate

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


@pytest.fixture
def contract_client(tmp_path, monkeypatch):
    monkeypatch.setenv("ZYRQUEN_API_KEY", "contract-test-key")
    monkeypatch.setenv("AUDIT_DB_PATH", str(tmp_path / "audit.db"))
    monkeypatch.setenv("AUDIT_REPORT_DIR", str(tmp_path / "reports"))
    module = importlib.import_module("ZYRQUEN_Audit_Trail_API_Chamber17")
    module = importlib.reload(module)
    with TestClient(module.app) as client:
        yield client, module.app.openapi()


@pytest.fixture
def auth_headers():
    return {"Authorization": "Bearer contract-test-key"}


def validate_response(schema, path, method, status, payload):
    operation = schema["paths"][path][method]
    response_schema = operation["responses"][str(status)]["content"]["application/json"]["schema"]
    resolver = RefResolver.from_schema(schema)
    validate(payload, response_schema, resolver=resolver)


def test_all_documented_json_endpoints_match_openapi(contract_client, auth_headers):
    client, schema = contract_client
    payload = {
        "seal_id": 14903,
        "chamber": "CONTRACT-CHAMBER",
        "module": "contract",
        "event_type": "CREATE",
        "details": "OpenAPI contract test event",
        "legal_sections": [28, 9],
        "forensic_ready": True,
    }

    cases = [
        ("/healthz", "get", None, None, 200),
        ("/api/v1/telemetry", "get", None, None, 200),
        ("/api/v1/audit/records", "get", auth_headers, None, 200),
        ("/api/v1/audit/records", "post", auth_headers, payload, 201),
    ]
    create = client.post("/api/v1/audit/records", json=payload, headers=auth_headers)
    assert create.status_code == 201
    cases.extend([
        ("/api/v1/audit/replay/{seal_id}", "post", auth_headers, None, 200),
        ("/api/v1/audit/report/generate", "post", auth_headers, {}, 201),
    ])

    for path, method, headers, body, expected in cases:
        actual_path = path.replace("{seal_id}", "14903")
        response = getattr(client, method)(actual_path, headers=headers, json=body) if body is not None else getattr(client, method)(actual_path, headers=headers)
        assert response.status_code == expected, (path, response.text)
        validate_response(schema, path, method, expected, response.json())


def test_openapi_documents_all_runtime_paths(contract_client):
    client, schema = contract_client
    runtime_paths = {route.path for route in client.app.routes if hasattr(route, "methods") and route.path in schema["paths"]}
    assert runtime_paths == set(schema["paths"])
    assert json.dumps(schema).find("HTTPBearer") >= 0
