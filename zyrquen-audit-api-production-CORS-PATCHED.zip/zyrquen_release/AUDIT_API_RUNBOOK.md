# ZYRQUEN Audit Trail API — Runbook

## สถานะ

ไฟล์ `ZYRQUEN_Audit_Trail_API_Chamber17.py` เป็น production baseline ที่มี SQLite persistence, Bearer API-key authentication, input validation, chained SHA-256 record hashes และ PDF report generation

ระบบนี้ **ไม่อ้างว่าเป็น** Dilithium verifier, HSM integration หรือการรับรองทางกฎหมาย หากต้องการความสามารถดังกล่าวต้องต่อ provider ที่ผ่านการตรวจสอบแยกต่างหาก

## ติดตั้ง

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-audit-api.txt
```

## ตั้งค่าและรัน

สร้าง API key ที่คาดเดายากและตั้งค่าก่อนเริ่มบริการ:

```bash
export ZYRQUEN_API_KEY="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')"
export AUDIT_DB_PATH="./data/audit.db"
export AUDIT_REPORT_DIR="./data/reports"
uvicorn ZYRQUEN_Audit_Trail_API_Chamber17:app --host 127.0.0.1 --port 8000
```

สำหรับการ deploy หลัง reverse proxy ให้ bind กับ interface ที่เหมาะสมและบังคับ HTTPS ที่ proxy อย่าเก็บ API key ลงใน source control

## ตัวอย่างการใช้งาน

ตรวจสุขภาพบริการ:

```bash
curl http://127.0.0.1:8000/healthz
```

สร้าง audit record:

```bash
curl -X POST http://127.0.0.1:8000/api/v1/audit/records \\
  -H "Authorization: Bearer $ZYRQUEN_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"seal_id":14903,"chamber":"CH-1","module":"audit","event_type":"CREATE","details":"example event","forensic_ready":false}'
```

อ่าน records แบบแบ่งหน้า:

```bash
curl "http://127.0.0.1:8000/api/v1/audit/records?limit=100&offset=0" \\
  -H "Authorization: Bearer $ZYRQUEN_API_KEY"
```

สร้างและดาวน์โหลด PDF:

```bash
curl -X POST http://127.0.0.1:8000/api/v1/audit/report/generate \\
  -H "Authorization: Bearer $ZYRQUEN_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{}' \\
  -o report-response.json

curl -L "http://127.0.0.1:8000$(python3 -c 'import json; print(json.load(open("report-response.json"))["download_url"])')" \\
  -H "Authorization: Bearer $ZYRQUEN_API_KEY" \\
  -o audit-report.pdf
```

## ข้อควรทำก่อน production จริง

ควรใช้ secret manager แทน environment file ธรรมดา, วางบริการหลัง HTTPS reverse proxy, จำกัด network access, ตั้ง backup และ retention ของ SQLite, เพิ่ม structured audit logging, เพิ่ม key rotation และต่อ cryptographic/HSM provider ที่ผ่านการตรวจสอบ การทำ hash chain ช่วยตรวจพบการเปลี่ยนแปลงใน record chain แต่ไม่ใช่ลายเซ็นดิจิทัลหรือหลักฐานความถูกต้องของข้อมูลจากต้นทาง

## รันด้วย Docker Compose

คัดลอกไฟล์ตัวอย่างเป็น `.env` แล้วสร้าง secret ใหม่ก่อนรัน:

```bash
cp .env.example .env
python3 -c 'import secrets; print(secrets.token_urlsafe(32))'
# นำค่าที่ได้ไปแทนที่ ZYRQUEN_API_KEY ใน .env
chmod 600 .env
docker compose build --pull
docker compose up -d
```

ตรวจสอบสถานะและ health check:

```bash
docker compose ps
docker compose logs -f audit-api
curl http://127.0.0.1:8000/healthz
```

Compose จะเก็บ SQLite database และ PDF reports ใน named volume `zyrquen_audit_data` และ bind port เฉพาะ `127.0.0.1` เพื่อให้ reverse proxy ที่อยู่บนเครื่องเดียวกันเป็นผู้เปิดบริการภายนอก หากต้องการเปิดจากเครือข่ายอื่น ควรทำผ่าน HTTPS reverse proxy และ firewall ที่กำหนด allowlist แทนการเปลี่ยนเป็น `0.0.0.0:8000:8000` โดยตรง

หยุดบริการโดยไม่ลบข้อมูล:

```bash
docker compose down
```

อย่าใช้ `docker compose down -v` เว้นแต่ตั้งใจลบฐานข้อมูลและรายงานทั้งหมด

## Nginx reverse proxy และ Let’s Encrypt

ไฟล์ที่เกี่ยวข้องคือ `deploy/nginx/zyrquen.conf`, `deploy/nginx/zyrquen-bootstrap.conf` และ `docker-compose.prod.yml` ก่อนเริ่มต้องชี้ DNS ของ `api.example.com` มายัง public IP ของเครื่อง และแทนที่ `api.example.com` ในไฟล์ Nginx ทั้งสองไฟล์ด้วยโดเมนจริงของคุณ ห้ามใช้ตัวอย่างนี้โดยไม่เปลี่ยนโดเมน

ขั้นตอนขอ certificate ครั้งแรก:

```bash
cp .env.example .env
chmod 600 .env
# แก้ไข ZYRQUEN_API_KEY ใน .env
# แก้ api.example.com ใน deploy/nginx/zyrquen-bootstrap.conf
# แก้ api.example.com ใน deploy/nginx/zyrquen.conf

cp deploy/nginx/zyrquen-bootstrap.conf deploy/nginx/active.conf
# ชั่วคราว แก้ docker-compose.prod.yml ให้ nginx mount ./deploy/nginx/active.conf แทน zyrquen.conf
docker compose -f docker-compose.prod.yml up -d audit-api nginx

docker compose -f docker-compose.prod.yml run --rm certbot certonly \\
  --webroot -w /var/www/certbot \\
  -d api.example.com \\
  --email admin@example.com \\
  --agree-tos --no-eff-email

cp deploy/nginx/zyrquen.conf deploy/nginx/active.conf
# เปลี่ยน nginx volume ใน docker-compose.prod.yml ให้ mount ./deploy/nginx/active.conf
docker compose -f docker-compose.prod.yml up -d nginx certbot
```

ตรวจสอบและ reload Nginx:

```bash
docker compose -f docker-compose.prod.yml exec nginx nginx -t
docker compose -f docker-compose.prod.yml exec nginx nginx -s reload
curl -fsS https://api.example.com/healthz
```

การต่ออายุ certificate จะทำโดย container `certbot` ทุก 12 ชั่วโมง แต่หลังต่ออายุสำเร็จควร reload Nginx เพื่อให้ process โหลด certificate ใหม่ หากต้องการ automation ที่สมบูรณ์ ควรเพิ่ม deployment hook หรือ scheduled job สำหรับ `nginx -s reload` และตรวจสอบผลด้วย monitoring ภายนอก

พอร์ต 80 และ 443 ต้องเปิดใน firewall เพื่อให้ ACME HTTP-01 challenge และ HTTPS ทำงาน ส่วนพอร์ต 8000 ไม่ควรเปิดสู่สาธารณะ เพราะ API อยู่หลัง Nginx แล้ว
