# Backup Strategy and Disaster Recovery Plan

## 1. เป้าหมายและขอบเขต

แผนนี้ครอบคลุมข้อมูลที่ API ใช้งานจริงใน Docker named volume `zyrquen_audit_data` ได้แก่ SQLite database `audit.db` และ PDF reports ใน `reports/` รวมถึง operational configuration ที่จำเป็นต่อการเปิดบริการใหม่ เช่น `.env` และ certificate material ซึ่งต้องสำรองแยกใน secret manager/secure vault ไม่ควรใส่รวมใน archive ธรรมดา

สคริปต์ใน `ops/` ทำหน้าที่ backup, verify และ restore data volume เท่านั้น ไม่ได้สำรอง Docker image registry, DNS, firewall, GitHub repository หรือ private keys โดยอัตโนมัติ

## 2. เป้าหมาย RPO/RTO ที่เสนอ

| ระดับ | เป้าหมาย | วิธีทำ |
|---|---:|---|
| RPO | ไม่เกิน 1 ชั่วโมง | รัน backup อย่างน้อยทุกชั่วโมงหรือถี่กว่านั้นตาม write volume |
| RTO | ไม่เกิน 2 ชั่วโมง | เตรียม host/image/secret ไว้ล่วงหน้าและใช้ restore runbook |
| Retention ระยะสั้น | 30 วัน | เก็บ local backup ที่เข้ารหัสและตรวจ checksum |
| Retention ระยะยาว | 12 เดือนหรือตามนโยบาย | เก็บ off-site/object storage แบบ immutable |
| Restore drill | รายไตรมาส | restore ไปยัง isolated volume และตรวจ API/record/report |

RPO/RTO เป็นข้อเสนอเริ่มต้น ไม่ใช่ SLA ที่รับประกันจากสคริปต์ ผู้ดูแลควรปรับตามจำนวนข้อมูล ความสำคัญของ audit records และข้อกำหนดขององค์กร

## 3. รูปแบบ backup

ให้ใช้หลัก **3-2-1**: มีข้อมูลอย่างน้อย 3 ชุด, อยู่บนสื่ออย่างน้อย 2 แบบ และมีอย่างน้อย 1 ชุดอยู่นอกเครื่อง production การสำรองใน named volume เดียวกับ production ไม่ถือเป็น off-site backup และไม่ป้องกัน disk failure, host compromise หรือ ransomware

`ops/backup.sh` ใช้ SQLite online backup API เพื่อสร้าง consistent snapshot โดยไม่ต้อง copy ไฟล์ SQLite ที่กำลังเขียนตรง ๆ จากนั้น archive `reports/`, สร้าง `manifest.json`, ตรวจ `PRAGMA integrity_check` และสร้าง `SHA256SUMS`

หลังสร้าง local backup สำเร็จ ควรเข้ารหัสและส่งไป object storage ที่มี versioning, retention lock/immutability และ least-privilege credentials ตัวอย่างเช่นใช้องค์กร-approved backup agent หรือ `rclone`/cloud CLI ที่ตั้งค่าในเครื่อง production แต่ไม่ควร hard-code provider credentials ใน repository

## 4. Encryption และการควบคุมสิทธิ์

ข้อมูล backup อาจมีรายละเอียด audit และ PDF reports จึงควรเข้ารหัสทั้งขณะส่งและขณะเก็บ ใช้ KMS-managed encryption หรือ public-key encryption ที่องค์กรควบคุม key เอง เก็บ encryption key/secret ใน KMS หรือ secret manager แยกจาก backup storage และทดสอบ key recovery ตามรอบที่กำหนด

ให้จำกัด permission ของ backup directory เป็น owner-only, ใช้ service account ที่เขียนได้แต่ไม่ลบ historical backups และแยกบัญชี restore ที่ต้องมี approval การเก็บ `.env`, API key, Grafana password และ TLS private key ควรอยู่ใน secret manager/secure vault ไม่ใช่ archive ที่ส่งต่อทั่วไป

## 5. ตารางเวลาปฏิบัติการ

| งาน | ความถี่ | ผู้รับผิดชอบ | หลักฐานความสำเร็จ |
|---|---|---|---|
| Local backup | ทุก 1 ชั่วโมง | systemd timer/backup operator | backup directory + manifest |
| Verify checksum/integrity | ทุก backup | backup script | exit code 0 และ log |
| Off-site replication | หลัง backup สำเร็จ | backup operator/agent | object version และ replication log |
| Restore drill | รายไตรมาส | operations + owner | drill report และ sample API checks |
| ทบทวน retention/access | รายเดือน | security/operations | access review record |

## 6. Disaster scenarios และ recovery

### กรณี API container เสีย แต่ volume ปกติ

สั่ง `docker compose up -d --build audit-api` หรือใช้ auto-healing ก่อน ไม่ต้อง restore backup เพราะ restore อาจย้อนข้อมูลโดยไม่จำเป็น

### กรณี database เสียหรือข้อมูลถูกแก้ไข

หยุด API, เลือก backup ล่าสุดที่ verify ผ่าน, สร้างสำเนา rollback ของ volume ปัจจุบันถ้ายังอ่านได้, รัน `ops/restore.sh` ด้วย explicit confirmation, start API และตรวจ health/record/report หลัง restore

### กรณี host หรือ volume หาย

เตรียม host ใหม่, ติดตั้ง Docker, checkout release จาก Git, วาง `.env`/certificates จาก secret vault, สร้าง services, restore backup ลง named volume, start stack และตรวจ Nginx, Prometheus, Grafana และ API ตามลำดับ

### กรณี ransomware หรือ credential compromise

ตัด host ออกจาก network ตาม incident procedure, revoke/rotate API keys และ registry/cloud credentials, ห้าม restore backup ที่เกิดหลังเวลาการ compromise, ใช้ immutable off-site backup ที่ verify แล้ว และให้ security owner อนุมัติก่อนเปิด traffic กลับ

## 7. เกณฑ์ตรวจหลัง restore

1. `ops/verify-backup.sh <backup-dir>` ต้องผ่าน
2. SQLite `PRAGMA integrity_check` ต้องคืน `ok`
3. `docker compose ps` ต้องแสดง services สำคัญเป็น healthy
4. `GET /healthz` ต้องคืน HTTP 200
5. `GET /api/v1/telemetry` ต้องอ่านได้
6. record ตัวอย่างต้องมี `record_hash` และ `previous_hash` ตาม chain
7. report ตัวอย่างต้อง download ได้และ checksum ตรงกับ metadata
8. Prometheus ต้อง scrape target และ Grafana ต้องเปิด dashboard ได้
9. DNS/TLS และ Nginx ต้องตรวจด้วย `nginx -t` และ HTTPS probe

## 8. ข้อจำกัดและการปรับปรุงระยะต่อไป

SQLite เหมาะกับ single-writer หรือ workload ขนาดเล็กถึงปานกลาง แต่หากมี concurrent writes สูง, ต้อง scale หลาย replica หรือจำเป็นต้องมี point-in-time recovery ควรย้ายไป PostgreSQL/managed database ที่มี WAL archiving, replication และ native backup tooling

Hash chain ใน application ช่วยตรวจพบการเปลี่ยนแปลงบางประเภท แต่ไม่ใช่ immutable storage หรือ external notarization ควรส่ง manifest/checksum ไปยังระบบที่แยก trust boundary และมี append-only retention หาก audit evidence มีความสำคัญสูง
