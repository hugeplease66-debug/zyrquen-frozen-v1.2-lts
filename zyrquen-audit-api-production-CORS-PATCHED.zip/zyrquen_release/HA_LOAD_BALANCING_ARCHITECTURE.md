# High Availability และ Load Balancing Architecture

## Executive Summary

ระบบปัจจุบันเป็น API แบบ FastAPI ที่รันด้วย worker เดียว ใช้ SQLite และเก็บ PDF reports ใน Docker volume ภายในเครื่องเดียว การเพิ่ม API containers หลายตัวหลัง load balancer ทำได้เฉพาะชั้น HTTP แต่ยังไม่ทำให้ระบบเป็น HA อย่างแท้จริง เพราะทุก replica ยังต้องเขียนฐานข้อมูลและไฟล์ที่มี state ร่วมกัน

> **ข้อสรุปหลัก:** ก่อน scale เป็น active-active ต้องย้าย state ออกจาก local SQLite volume ไปยังฐานข้อมูลแบบ client/server ที่มี replication และย้าย PDF reports ไป object storage แบบ durable หากยังคง SQLite ให้ใช้ได้เพียง active-passive ที่มี single writer และ fencing ชัดเจน

SQLite อาศัย file locking และ filesystem semantics ของเครื่องที่เก็บไฟล์ การวาง database file บน network filesystem มีความเสี่ยงด้าน locking, ordering และ corruption ตามเอกสาร SQLite [1] [2] ดังนั้นไม่ควร mount `audit.db` บน NFS/SMB แล้วให้หลายโหนดเขียนพร้อมกัน

## เป้าหมายเริ่มต้น

| เป้าหมาย | ค่าออกแบบเบื้องต้น |
|---|---:|
| API availability | 99.9% ต่อเดือน |
| API replicas | อย่างน้อย 3 ตัว กระจายอย่างน้อย 2 availability zones |
| RPO | 0–5 นาทีสำหรับ database เมื่อใช้ synchronous/near-synchronous replication; ตรวจสอบกับ provider |
| RTO | 15–30 นาทีสำหรับ node failure; 1–2 ชั่วโมงสำหรับ regional recovery |
| Load balancing | L7 HTTPS load balancer พร้อม active health check และ connection draining |
| Session model | Stateless; ไม่ใช้ sticky session |
| Public ports | 443 และ 80 สำหรับ redirect/ACME เท่านั้น |
| Internal ports | API, database, metrics และ Grafana ไม่เปิด public โดยตรง |

ค่าเหล่านี้เป็น design targets ไม่ใช่ SLA ที่รับประกัน ควรยืนยันด้วย capacity test และ failover drill

## สถาปัตยกรรมเป้าหมายที่แนะนำ

```mermaid
flowchart TB
    U[Clients] --> DNS[Managed DNS / Health-aware DNS]
    DNS --> LB[Regional L7 Load Balancer\nTLS termination + WAF + rate limit]
    LB --> ING1[Ingress / Nginx node A]
    LB --> ING2[Ingress / Nginx node B]
    ING1 --> API1[API replica 1]
    ING1 --> API2[API replica 2]
    ING2 --> API3[API replica 3]
    API1 --> DBP[(PostgreSQL HA primary/service endpoint)]
    API2 --> DBP
    API3 --> DBP
    DBP -. sync/async replication .-> DBS[(PostgreSQL standby / failover node)]
    API1 --> OBJ[(Object storage: PDF reports)]
    API2 --> OBJ
    API3 --> OBJ
    API1 --> REDIS[(Optional Redis: rate limit / idempotency)]
    API2 --> REDIS
    API3 --> REDIS
    API1 --> OTEL[Metrics/log collector]
    API2 --> OTEL
    API3 --> OTEL
    PROM1[Prometheus A] --> API1
    PROM2[Prometheus B] --> API2
    PROM1 --> G[Grafana / Alertmanager]
    PROM2 --> G
```

### ส่วนประกอบ

| ชั้น | การออกแบบ | เหตุผล |
|---|---|---|
| DNS/WAF/LB | Managed L7 load balancer, TLS, WAF, rate limit | เอา public ingress ออกจาก host เดี่ยวและทำ health-based routing |
| Ingress | Nginx หรือ managed ingress อย่างน้อย 2 โหนด | รองรับ connection draining และไม่เป็น single point of failure |
| API | 3+ stateless replicas, 1 worker ต่อ container หรือปรับตาม CPU | scale out ได้โดยไม่พึ่ง local process state |
| Database | Managed PostgreSQL HA, primary + standby, failover endpoint | รองรับ concurrent writes และ replication แบบ database-native |
| Files | S3-compatible object storage พร้อม versioning | PDF ไม่ผูกกับ node ใด node หนึ่ง |
| Cache/control | Redis แบบ HA เฉพาะ rate limit/idempotency หากจำเป็น | หลีกเลี่ยงการเก็บ session/state ใน process memory |
| Monitoring | Prometheus อย่างน้อย 2 instances, Grafana, Alertmanager | Prometheus ระบุว่าสามารถรัน identical instances หลายเครื่องและ deduplicate ผ่านระบบที่เหมาะสมได้ [3] |
| Logs | JSON stdout → collector → Loki/OpenSearch/SIEM | Metrics ไม่ใช่ระบบจัดเก็บ event logs; Prometheus แนะนำให้ใช้ระบบ logs แยก เช่น Loki [3] |
| Secrets | Secret manager/KMS | แยก API key, DB credentials, TLS key และ registry credentials จาก image/repository |

## Load Balancing และ Health Model

ควรแยก endpoint สำหรับ liveness และ readiness:

| Endpoint | ใช้โดย | ความหมาย |
|---|---|---|
| `/healthz` | container/runtime | process ยังตอบสนอง ไม่ควร query dependency ที่ช้า |
| `/readyz` | load balancer/orchestrator | พร้อมรับ traffic และเชื่อมต่อ database/object storage ได้ |
| `/metrics` | Prometheus internal network | metrics เท่านั้น ไม่เปิดผ่าน public Nginx |

Load balancer ควรส่ง traffic เฉพาะ replica ที่ `/readyz` ผ่าน, ใช้ timeout ที่กำหนด, retry เฉพาะ GET/idempotent requests และทำ connection draining ก่อนถอด replica ออกจาก pool ไม่ควร retry POST สร้าง audit record โดยไม่มี idempotency key เพราะอาจสร้าง record ซ้ำ

API ควรส่ง `X-Request-ID` ต่อเนื่องจาก edge ถึง application log และต้องไม่ใช้ client-provided ID โดยไม่ validate ความยาว/ตัวอักษร ควรกำหนด maximum body size, per-client rate limit และ upstream connection limit ที่ edge

## Data Layer ที่ต้องเปลี่ยนก่อน Active-Active

### Database

เปลี่ยน persistence layer จาก SQLite เป็น PostgreSQL โดยให้ API ใช้ connection pool และเชื่อมต่อผ่าน stable writer endpoint หรือ proxy ที่รู้ primary/standby state ไม่ควรให้ application เลือก IP primary เอง

PostgreSQL มี primary/standby model สำหรับ streaming replication และรองรับ synchronous standby configuration [4] การเลือก synchronous replication จะเพิ่ม data durability แต่เพิ่ม write latency และอาจทำให้ write unavailable หากไม่มี standby ที่พร้อม จึงต้องกำหนด policy ระหว่าง availability กับ zero/minimal data loss ให้ชัดเจน

โครงสร้างตารางควรเพิ่ม:

1. `record_id` เป็น UUID หรือ database-generated key ที่ unique ข้ามทุก replica
2. unique constraint บน `idempotency_key` หาก endpoint create รองรับ retry
3. `created_at` เป็น UTC และ index บน `seal_id`, `created_at`, `section`
4. transaction isolation ที่เหมาะกับ hash-chain ordering
5. กลไก sequence/serialization สำหรับ `previous_hash` เพื่อไม่ให้ concurrent writes สร้าง chain fork

**ประเด็นสำคัญ:** hash chain แบบลำดับเดียวไม่สามารถสร้างอย่างปลอดภัยด้วยหลาย writer โดยไม่มี serialization หากยังต้องการ chain เดียว ให้ใช้ database transaction ที่ lock logical stream หรือแบ่ง chain ตาม tenant/partition แล้วมี external checkpoint service

### PDF reports

ย้ายไฟล์ PDF จาก local `/app/data/reports` ไป object storage โดยเก็บเพียง metadata ใน database ได้แก่ object key, content hash, size, MIME type, created time และ encryption key ID การดาวน์โหลดควรคืน short-lived presigned URL หรือ stream ผ่าน API ที่ตรวจ authorization

## ถ้ายังต้องใช้ SQLite ชั่วคราว

ใช้รูปแบบ active-passive เท่านั้น:

```text
LB/DNS -> active API node -> local SQLite volume
                    \-> passive node, no writer
```

ต้องมี distributed lock/fencing หรือ orchestration ที่รับรองว่าเขียนได้เพียง node เดียว ห้ามใช้ shared network filesystem เป็นวิธีแก้ multi-writer และควรทดสอบ filesystem locking บน infrastructure จริงก่อนใช้งาน การ failover ต้องหยุดหรือ fence node เก่าก่อน promote node ใหม่เพื่อป้องกัน split-brain

รูปแบบนี้ให้ HA ต่ำกว่า PostgreSQL และมี RPO ตามรอบ backup/replication ไม่เหมาะกับ active-active หรือ write-heavy workload

## Failure Modes และการตอบสนอง

| Failure | Detection | Response | Data risk |
|---|---|---|---|
| API replica ตาย | LB `/readyz`, container healthcheck | drain และ replace replica | ต่ำ หาก state externalized |
| Ingress node ตาย | LB healthcheck | route ไป node อื่น | ต่ำ |
| Database primary ตาย | DB HA manager/endpoint | promote standby, rotate connection pool | ขึ้นกับ replication lag |
| Network partition | cross-zone probes, DB quorum | fence ฝั่งที่ไม่มี quorum; ห้าม promote สองฝั่ง | split-brain หากไม่มี fencing |
| Object storage unavailable | readiness dependency policy + alerts | หยุด report creation หรือ queue retry; อย่ารายงาน success ก่อน durable write | PDF อาจสูญหายหากเก็บ local อย่างเดียว |
| Prometheus ตาย | external monitor | ใช้ Prometheus อีก instance; alert via Alertmanager | observability gap |
| Region ตาย | DNS/Global LB | promote secondary region ตาม DR runbook | RPO/RTO ระดับ region |
| Bad deploy | error rate/latency alerts | rollback immutable image/tag | ต่ำถ้า migration backward-compatible |

## Observability สำหรับหลายโหนด

แต่ละ API replica ต้องส่ง metrics ที่มี label ต่ำและคงที่ เช่น `service`, `route`, `method`, `status_code`, `zone` ห้ามใส่ `record_id`, `report_id`, IP เต็ม หรือ user ID เป็น label เพราะทำให้ series cardinality สูง

ควรเพิ่ม dashboard และ alerts ต่อไปนี้:

| Signal | Alert baseline |
|---|---|
| Availability | `up == 0`, readiness failures, LB 5xx |
| Errors | 5xx rate > 1–5% ต่อเนื่อง 5 นาที |
| Latency | p95/p99 แยก route และ zone |
| Saturation | CPU, memory, file descriptors, connection pool, disk |
| Database | replication lag, connection exhaustion, lock wait, WAL/archive failure |
| Storage | object upload errors, latency, quota, orphan metadata |
| Data integrity | hash-chain validation failures, checksum mismatch, restore drill failure |

Prometheus ควรมีอย่างน้อยสอง instances ที่ scrape targets ชุดเดียวกัน และใช้ Alertmanager HA หรือระบบ deduplication ที่เหมาะสม [3]

## Deployment และ Migration Plan

### Phase 0 — Baseline

กำหนด SLO, RPO/RTO, data classification, load profile และ failover owner จากนั้นเพิ่ม `/readyz`, idempotency contract, graceful shutdown, connection draining และ migration-compatible schema

### Phase 1 — Externalize files

ย้าย PDF reports ไป object storage แบบ versioning/encryption ก่อน โดยทำ dual-write และ verify content hash จนมั่นใจว่า object ครบ จากนั้นเปลี่ยน read path ให้ object storage เป็น source of truth

### Phase 2 — Migrate SQLite ไป PostgreSQL

หยุด write ชั่วคราวหรือใช้ controlled dual-write, export/import พร้อม row counts และ hash totals, ตรวจ audit chain, แล้วทำ cutover ไป PostgreSQL ผ่าน feature flag คง SQLite backup ไว้ตาม retention จนผ่าน restore drill

### Phase 3 — Database HA

สร้าง primary/standby อย่างน้อยต่าง availability zones, ตั้ง backup/WAL archive, failover endpoint และ fencing ทดสอบ promotion, rollback และ connection recovery โดยไม่ให้ API มี hard-coded primary IP

### Phase 4 — Scale API

สร้าง immutable image, deploy API อย่างน้อย 3 replicas, วางบนหลาย zones, ตั้ง readiness/liveness, rolling update, PDB/anti-affinity หากใช้ orchestrator และทดสอบ no-sticky-session

### Phase 5 — Edge และ observability HA

เพิ่ม load balancer/WAF แบบ redundant, Prometheus สอง instances, Grafana/Alertmanager policy, centralized logs และ external synthetic probes

### Phase 6 — Game days

ทดสอบ node loss, zone loss, database failover, object storage outage, bad deployment, expired certificate, disk full และ secret rotation อย่างน้อยรายไตรมาส พร้อมเก็บ measured RPO/RTO ไม่ใช่เพียงผล PASS/FAIL

## Acceptance Tests ก่อน Go-live

1. ยิง concurrent reads/writes ผ่าน load balancer แล้วไม่พบ duplicate หรือ chain fork
2. ถอด API replica ทีละตัว ระบบยังคงตอบ 200 ตาม SLO
3. drain node และ deploy version ใหม่โดยไม่มี request สำคัญสูญหาย
4. promote database standby แล้ว API reconnect ได้โดยไม่แก้ image/config แบบ manual
5. object storage fail แล้ว API ไม่รายงานสร้าง PDF สำเร็จก่อน durable write
6. Prometheus instance หนึ่งหยุดทำงานแต่ยังมี alert จากอีก instance
7. ปิด zone หนึ่งแล้วยังมี capacity เพียงพอ
8. restore database + objects บน isolated environment และตรวจ row count, hash, PDF checksum
9. ทดสอบ split-brain/fencing และยืนยันว่าไม่มีสอง primary ที่รับ write พร้อมกัน
10. ตรวจว่า `/metrics`, database และ Grafana ไม่เปิด public โดยตรง

## ข้อเสนอแนะสรุป

สำหรับระบบนี้ เส้นทางที่เหมาะสมคือ **managed L7 load balancer + API replicas 3 ตัว + PostgreSQL HA + object storage + redundant Prometheus/Alertmanager + centralized logs** การเพิ่ม API containers หลายตัวโดยคง SQLite volume เดิมไว้จะเพิ่มความซับซ้อนและความเสี่ยงมากกว่าความพร้อมใช้งานที่ได้

ถ้าต้องการเริ่มด้วยต้นทุนต่ำ ให้ใช้ active-passive SQLite ชั่วคราวพร้อม fencing และ backup ที่ตรวจสอบได้ แต่ควรกำหนดเป็น transitional architecture พร้อม deadline ย้ายไป PostgreSQL ไม่ควรใช้เป็นเป้าหมายระยะยาวสำหรับ multi-node active-active

## References

[1]: https://www.sqlite.org/draft/useovernet.html "SQLite Over a Network: Caveats and Considerations"
[2]: https://sqlite.org/lockingv3.html "File Locking And Concurrency In SQLite Version 3"
[3]: https://prometheus.io/docs/introduction/faq/ "Prometheus FAQ: High Availability and Logs"
[4]: https://www.postgresql.org/docs/current/runtime-config-replication.html "PostgreSQL Documentation: Replication Configuration"
