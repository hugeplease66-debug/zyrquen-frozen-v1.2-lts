# ZYRQUEN Audit Trail API — API Documentation / User Guide

เอกสารนี้อธิบายการติดตั้ง การตั้งค่า การยืนยันตัวตน endpoint รูปแบบข้อมูล ตัวอย่างคำตอบ และการใช้งานด้วย cURL สำหรับ `ZYRQUEN_Audit_Trail_API_Chamber17.py` เวอร์ชัน production baseline

> API นี้มี SQLite persistence, Bearer API-key authentication, input validation, chained SHA-256 record hashes และการสร้าง PDF จริง แต่ **ไม่ได้เป็น** การตรวจสอบ Dilithium-5, HSM หรือการรับรองทางกฎหมายโดยอัตโนมัติ

## 1. ข้อมูลเบื้องต้น

| รายการ | ค่าเริ่มต้น |
|---|---|
| Base URL ภายในเครื่อง | `http://127.0.0.1:8000` |
| Base URL หลัง Nginx | `https://api.example.com` |
| Health endpoint | `GET /healthz` |
| API prefix | `/api/v1` |
| Authentication | `Authorization: Bearer <ZYRQUEN_API_KEY>` |
| Database | SQLite ที่ `AUDIT_DB_PATH` |
| Report storage | Directory ที่ `AUDIT_REPORT_DIR` |
| Canonical block | `849202` เว้นแต่กำหนด `CANONICAL_BLOCK_HEIGHT` ใหม่ |

ตัวอย่างต่อไปนี้กำหนดตัวแปรเพื่อให้คัดลอกไปใช้ได้ง่าย:

```bash
export BASE_URL="http://127.0.0.1:8000"
export ZYRQUEN_API_KEY="replace-with-your-real-api-key"
export AUTH_HEADER="Authorization: Bearer ${ZYRQUEN_API_KEY}"
```

เมื่อรันผ่าน Nginx ให้เปลี่ยน `BASE_URL` เป็น `https://api.example.com` และต้องใช้ HTTPS เสมอ

## 2. เริ่มต้นบริการ

### 2.1 ติดตั้งโดยตรงด้วย Python

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements-audit-api-runtime.txt
export ZYRQUEN_API_KEY="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')"
export AUDIT_DB_PATH="./data/audit.db"
export AUDIT_REPORT_DIR="./data/reports"
uvicorn ZYRQUEN_Audit_Trail_API_Chamber17:app --host 127.0.0.1 --port 8000
```

### 2.2 เริ่มต้นด้วย Docker Compose

```bash
cp .env.example .env
# แก้ ZYRQUEN_API_KEY ใน .env เป็น secret ที่สุ่มใหม่
chmod 600 .env
docker compose -f docker-compose.prod.yml up -d
docker compose -f docker-compose.prod.yml ps
```

หากใช้ Nginx/Let’s Encrypt ให้ทำตามขั้นตอน bootstrap certificate ใน `AUDIT_API_RUNBOOK.md` ก่อนใช้ `https://` ใน production

## 3. Authentication

Endpoint ที่ขึ้นต้นด้วย `/api/v1/audit/` ต้องใช้ Bearer token โดยส่ง header ดังนี้:

```http
Authorization: Bearer <ZYRQUEN_API_KEY>
```

ตัวอย่าง:

```bash
curl --fail-with-body -sS \
  -H "Authorization: Bearer ${ZYRQUEN_API_KEY}" \
  "${BASE_URL}/api/v1/audit/records"
```

พฤติกรรมเมื่อ authentication ผิดพลาด:

| สถานการณ์ | HTTP status | ความหมาย |
|---|---:|---|
| ไม่มี header หรือไม่ใช่ Bearer | `401` | ต้องส่ง Bearer token |
| token ไม่ตรงกับ `ZYRQUEN_API_KEY` | `403` | token ไม่ถูกต้อง |
| server ไม่มี `ZYRQUEN_API_KEY` | `503` | ยังไม่ได้ตั้งค่า secret ฝั่ง server |

ห้ามใส่ API key ลงใน source code, Git, URL query string หรือ log ที่เผยแพร่สู่สาธารณะ

## 4. Health check — `GET /healthz`

ใช้ตรวจว่ากระบวนการ API ตอบสนองอยู่ โดยไม่ต้อง authentication:

```bash
curl --fail-with-body -sS "${BASE_URL}/healthz"
```

ตัวอย่าง response:

```json
{
  "status": "ok",
  "version": "2.0.0"
}
```

## 5. Telemetry — `GET /api/v1/telemetry`

Endpoint นี้ไม่ต้อง authentication และคืนสถานะเชิงสถิติของ application รวมจำนวน audit records ที่จัดเก็บอยู่ใน SQLite:

```bash
curl --fail-with-body -sS \
  "${BASE_URL}/api/v1/telemetry"
```

ตัวอย่าง response:

```json
{
  "status": "operational",
  "block_height": 849202,
  "canonical_seals_count": 0,
  "genesis_hash": "909ab814479844d8a14816bed34cdbb07528e18501da86fc4691763a43fa4c68",
  "generated_at": 1780000000.123
}
```

`generated_at` เป็น Unix timestamp และ `canonical_seals_count` คือจำนวน records ใน database ไม่ใช่จำนวน seals จากระบบภายนอก

## 6. สร้าง audit record — `POST /api/v1/audit/records`

สร้างและจัดเก็บ audit record ใหม่ โดย server จะเติม `record_id`, `created_at`, `previous_hash` และ `record_hash` ให้เอง

### Request fields

| Field | Type | Required | ข้อจำกัด |
|---|---|---:|---|
| `seal_id` | integer หรือ null | ไม่ | 0 ถึง 10,000,000 |
| `chamber` | string | ใช่ | ความยาว 1–120 |
| `module` | string | ใช่ | ความยาว 1–120 |
| `event_type` | string | ใช่ | ความยาว 1–120 |
| `details` | string | ใช่ | ความยาว 1–20,000 |
| `legal_sections` | array ของ integer | ไม่ | แต่ละค่า 1–999; ค่าซ้ำจะถูกตัดออกและเรียงลำดับ |
| `forensic_ready` | boolean | ไม่ | ค่าเริ่มต้น `false` |

ตัวอย่างสร้าง record:

```bash
curl --fail-with-body -sS -X POST \
  -H "Authorization: Bearer ${ZYRQUEN_API_KEY}" \
  -H "Content-Type: application/json" \
  "${BASE_URL}/api/v1/audit/records" \
  -d '{
    "seal_id": 14903,
    "chamber": "CH-1",
    "module": "audit",
    "event_type": "CREATE",
    "details": "User-created audit event",
    "legal_sections": [28, 9, 9],
    "forensic_ready": false
  }'
```

ตัวอย่าง response status `201`:

```json
{
  "seal_id": 14903,
  "chamber": "CH-1",
  "module": "audit",
  "event_type": "CREATE",
  "details": "User-created audit event",
  "legal_sections": [9, 28],
  "forensic_ready": false,
  "record_id": "8d8c0c2b-2de1-4bb1-a1e5-000000000000",
  "created_at": 1780000000.456,
  "previous_hash": "909ab814479844d8a14816bed34cdbb07528e18501da86fc4691763a43fa4c68",
  "record_hash": "a sha-256 hash with 64 hexadecimal characters"
}
```

`record_hash` ถูกคำนวณจากข้อมูลแบบ canonical JSON และ `previous_hash` จึงทำหน้าที่เป็น hash chain ระหว่าง records ตามลำดับการเขียน

## 7. อ่าน audit records — `GET /api/v1/audit/records`

อ่าน records ที่บันทึกไว้ ต้อง authentication รองรับการกรองด้วย chamber และ pagination

| Query parameter | ค่าเริ่มต้น | ช่วง/ความหมาย |
|---|---:|---|
| `chamber` | ไม่มี | exact match ของ chamber |
| `limit` | `100` | 1–500 |
| `offset` | `0` | ต้องไม่ติดลบ |

อ่าน records ล่าสุด 100 รายการ:

```bash
curl --fail-with-body -sS \
  -H "Authorization: Bearer ${ZYRQUEN_API_KEY}" \
  "${BASE_URL}/api/v1/audit/records?limit=100&offset=0"
```

อ่านเฉพาะ chamber ที่ต้องการ:

```bash
curl --fail-with-body -sS \
  -H "Authorization: Bearer ${ZYRQUEN_API_KEY}" \
  --get "${BASE_URL}/api/v1/audit/records" \
  --data-urlencode "chamber=CH-1" \
  --data-urlencode "limit=50" \
  --data-urlencode "offset=0"
```

ผลลัพธ์เรียงจาก record ล่าสุดไปเก่าสุด และคืนเป็น JSON array หากยังไม่มี record จะคืน `[]`

## 8. Replay ตาม seal — `POST /api/v1/audit/replay/{seal_id}`

ค้นหา records ที่จัดเก็บไว้ด้วย `seal_id` และคืนรายการ record ที่ตรงกัน ฟังก์ชันนี้เป็นการ replay metadata ของ records ในฐานข้อมูล ไม่ใช่การจำลองเครื่องมือ forensic ภายนอก

สร้าง record แล้ว replay:

```bash
curl --fail-with-body -sS -X POST \
  -H "Authorization: Bearer ${ZYRQUEN_API_KEY}" \
  "${BASE_URL}/api/v1/audit/replay/14903"
```

ตัวอย่าง response status `200`:

```json
{
  "seal_id": 14903,
  "status": "REPLAY_COMPLETE",
  "stages_executed": [
    "STAGE-01",
    "STAGE-02",
    "STAGE-03",
    "STAGE-04",
    "STAGE-05",
    "STAGE-06",
    "STAGE-07",
    "STAGE-08",
    "STAGE-09",
    "STAGE-10",
    "STAGE-11",
    "STAGE-12"
  ],
  "matching_record_ids": ["8d8c0c2b-2de1-4bb1-a1e5-000000000000"],
  "replayed_at": 1780000000.789
}
```

หากไม่มี record ของ seal นั้น จะคืน `404`. ค่า `seal_id` ติดลบหรือเกิน 10,000,000 จะคืน `422`

## 9. สร้าง PDF report — `POST /api/v1/audit/report/generate`

สร้าง PDF จริงใน `AUDIT_REPORT_DIR` และบันทึก metadata/hash ของ report ลง SQLite โดย `block_height` ต้องตรงกับค่า canonical ที่ server กำหนด

สร้าง report ด้วยค่ามาตรฐาน:

```bash
curl --fail-with-body -sS -X POST \
  -H "Authorization: Bearer ${ZYRQUEN_API_KEY}" \
  -H "Content-Type: application/json" \
  "${BASE_URL}/api/v1/audit/report/generate" \
  -d '{}'
```

สร้าง report โดยไม่รวมจำนวน records ในเอกสาร:

```bash
curl --fail-with-body -sS -X POST \
  -H "Authorization: Bearer ${ZYRQUEN_API_KEY}" \
  -H "Content-Type: application/json" \
  "${BASE_URL}/api/v1/audit/report/generate" \
  -d '{"block_height": 849202, "include_records": false}'
```

ตัวอย่าง response status `201`:

```json
{
  "report_id": "ZYR-AUD-AB12CD34",
  "file_name": "ZYR-AUD-AB12CD34.pdf",
  "download_url": "/api/v1/audit/report/ZYR-AUD-AB12CD34/download",
  "sha256": "a sha-256 hash with 64 hexadecimal characters",
  "created_at": 1780000001.123
}
```

หากส่ง `block_height` ไม่ตรงกับค่า server จะคืน `400`

## 10. ดาวน์โหลด PDF — `GET /api/v1/audit/report/{report_id}/download`

ดาวน์โหลด report ที่สร้างไว้ โดยต้องใช้ authentication:

```bash
export REPORT_ID="ZYR-AUD-AB12CD34"
curl --fail-with-body -sS -L \
  -H "Authorization: Bearer ${ZYRQUEN_API_KEY}" \
  "${BASE_URL}/api/v1/audit/report/${REPORT_ID}/download" \
  -o audit-report.pdf

file audit-report.pdf
sha256sum audit-report.pdf
```

หาก report ID ไม่มีอยู่จะคืน `404` และหาก metadata มีอยู่แต่ไฟล์ถูกลบจะคืน `410`

## 11. HTTP status codes ที่ควรรู้

| Status | กรณี |
|---:|---|
| `200` | อ่านข้อมูล, health check หรือ replay สำเร็จ |
| `201` | สร้าง audit record หรือ report สำเร็จ |
| `400` | block height ไม่ตรงกับ canonical block |
| `401` | ไม่มีหรือใช้รูปแบบ Authorization header ผิด |
| `403` | Bearer token ไม่ถูกต้อง |
| `404` | ไม่พบ seal หรือ report |
| `410` | พบ report metadata แต่ไฟล์หายไป |
| `422` | request body หรือ query/path parameter ไม่ผ่าน validation |
| `503` | server ยังไม่ได้ตั้ง `ZYRQUEN_API_KEY` |

## 12. การดู OpenAPI documentation

FastAPI เปิดเอกสาร interactive โดยอัตโนมัติ:

```bash
# Swagger UI
open "${BASE_URL}/docs"

# OpenAPI JSON
curl --fail-with-body -sS "${BASE_URL}/openapi.json"
```

บน Linux ที่ไม่มี `open` ให้เปิด URL ด้วย browser เอง หรือใช้ `xdg-open`

## 13. แนวทางใช้งาน production อย่างปลอดภัย

ควรเปิด API ผ่าน HTTPS reverse proxy และไม่เปิด port `8000` สู่สาธารณะโดยตรง ควรเก็บ `ZYRQUEN_API_KEY` ใน secret manager หรือ protected environment file, หมุน key เป็นระยะ, จำกัดสิทธิ์ไฟล์ database/report directory, สำรอง volume และตรวจสอบ log/health จากระบบ monitoring ภายนอก

Hash chain ช่วยตรวจพบการแก้ไข records ใน chain ได้บางส่วน แต่ไม่ใช่ digital signature, ไม่ยืนยันแหล่งที่มาของข้อมูล และไม่แทนการรับรอง HSM หรือ legal compliance การอ้างอิงทางกฎหมายหรือการนำข้อมูลไปใช้เป็นหลักฐานต้องผ่านการตรวจสอบโดยผู้เชี่ยวชาญที่เกี่ยวข้อง

## 14. Automated tests

รันชุดทดสอบทั้งหมดจาก repository root:

```bash
chmod +x run_api_tests.sh
./run_api_tests.sh
```

ชุดทดสอบจะใช้ temporary SQLite database และ API key สำหรับการทดสอบ จึงไม่กระทบ database production


## 15. Endpoint matrix สำหรับนักพัฒนา

ตารางนี้เป็น quick reference ของ endpoint ทั้งหมดใน API เวอร์ชันปัจจุบัน:

| Method | Path | Auth | Success | หน้าที่ |
|---|---|---|---:|---|
| `GET` | `/healthz` | ไม่ต้องใช้ | `200` | Liveness ของ process |
| `GET` | `/metrics` | ไม่ต้องใช้ | `200` | Prometheus exposition; ควรเข้าถึงได้เฉพาะ internal network |
| `GET` | `/api/v1/telemetry` | ไม่ต้องใช้ | `200` | สถานะ telemetry และจำนวน records |
| `POST` | `/api/v1/audit/records` | Bearer | `201` | สร้าง audit record และ hash-chain entry |
| `GET` | `/api/v1/audit/records` | Bearer | `200` | อ่าน records แบบ filter/pagination |
| `POST` | `/api/v1/audit/replay/{seal_id}` | Bearer | `200` | replay metadata ของ seal ที่มีอยู่ |
| `POST` | `/api/v1/audit/report/generate` | Bearer | `201` | สร้าง PDF report และบันทึก metadata |
| `GET` | `/api/v1/audit/report/{report_id}/download` | Bearer | `200` | ดาวน์โหลด PDF report |

## 16. Request ID และการติดตามคำขอ

ทุก request สามารถส่ง `X-Request-ID` ได้ หากไม่ส่ง server จะสร้าง UUID ให้เอง response จะคืนค่า `X-Request-ID` เดิม และ JSON log จะบันทึก request ID, method, normalized path, status code และ duration แต่ไม่บันทึก API key หรือ request body

```bash
REQUEST_ID="$(uuidgen 2>/dev/null || cat /proc/sys/kernel/random/uuid)"
curl --fail-with-body -sS \
  -H "X-Request-ID: ${REQUEST_ID}" \
  "${BASE_URL}/healthz" \
  -D response.headers.json
```

สำหรับ incident investigation ให้ค้นหา request ID เดียวกันใน Nginx access log, application log และ tracing system หากมี ห้ามใช้ข้อมูลส่วนบุคคลหรือ token เป็น request ID

## 17. รูปแบบ error response

Validation errors จาก FastAPI จะใช้ HTTP `422` และมีรายละเอียด field-level ใน `detail` ส่วน errors ที่ API สร้างเองจะมี `detail` เป็นข้อความ เช่น:

```json
{
  "detail": "Invalid API key"
}
```

ตัวอย่าง validation error:

```json
{
  "detail": [
    {
      "type": "string_too_long",
      "loc": ["body", "details"],
      "msg": "String should have at most 20000 characters",
      "input": "..."
    }
  ]
}
```

Client ควรจัดการ `401` โดยขอ credentials/configuration ที่ถูกต้อง, `403` โดยไม่ retry token เดิม, `422` โดยแก้ request, `429` หากมี rate limit จาก edge และ `5xx` ด้วย exponential backoff เฉพาะ operation ที่ปลอดภัยต่อการ retry

## 18. Schema contract ที่ต้องรักษา

`AuditRecordCreate` บังคับ `chamber`, `module`, `event_type` และ `details`; `seal_id` เป็น optional integer ระหว่าง 0 ถึง 10,000,000; `legal_sections` เป็น integer ระหว่าง 1 ถึง 999 และ server จะ deduplicate/sort ค่าเหล่านี้ ส่วน response `AuditRecord` จะเติม `record_id`, `created_at`, `previous_hash` และ `record_hash`

`ReportRequest.block_height` ต้องเป็น non-negative integerและต้องตรงกับค่า `CANONICAL_BLOCK` ของ server จึงจะสร้าง report ได้ ส่วน `include_records` มีค่าเริ่มต้นเป็น `true` หากไม่ต้องการให้ report รวมจำนวน records ให้ส่ง `false`

## 19. Idempotency และ retry policy

เวอร์ชันปัจจุบันยังไม่มี `Idempotency-Key` สำหรับ `POST /api/v1/audit/records` หรือ `POST /api/v1/audit/report/generate` ดังนั้น client ไม่ควร retry POST แบบ blind retry หลัง network timeout เพราะอาจสร้าง record หรือ report ซ้ำ หากต้องการใช้งานผ่าน load balancer ควรเพิ่ม idempotency key และ unique constraint ใน database ก่อนเปิด retry อัตโนมัติ

GET requests สามารถ retry ได้ตาม timeout policy แต่ต้องกำหนด total deadline และจำกัดจำนวนครั้ง ไม่ควร retry เมื่อได้รับ `401`, `403`, `404` หรือ `422`

## 20. OpenAPI และ interactive documentation

FastAPI สร้าง OpenAPI schema และ interactive documentation ตามมาตรฐาน OpenAPI โดยอัตโนมัติ [1] [2] เมื่อ server ทำงานแล้ว endpoints สำหรับเอกสารคือ:

| URL | การใช้งาน |
|---|---|
| `/openapi.json` | machine-readable OpenAPI schema |
| `/docs` | Swagger UI |
| `/redoc` | ReDoc |

```bash
curl --fail-with-body -sS "${BASE_URL}/openapi.json" -o openapi.runtime.json
```

สำหรับการ export โดยไม่ต้อง start server:

```bash
OPENAPI_OUTPUT=openapi.json python3 tools/export_openapi.py
python3 tools/validate_openapi.py
```

ควร commit `openapi.json` เมื่อใช้เป็น contract artifact ใน release และตรวจ diff ทุกครั้งที่แก้ endpoint, schema, security scheme หรือ status code การเผยแพร่ `/docs` ต่อ public internet ควรพิจารณา policy เพราะ schema อาจเปิดเผย topology และรูปแบบข้อมูลของระบบ

## 21. Developer workflow

ก่อนเปิด pull request ให้รันคำสั่งต่อไปนี้จาก project root:

```bash
./run_api_tests.sh
python3 tools/export_openapi.py
python3 tools/validate_openapi.py
python3 -m py_compile ZYRQUEN_Audit_Trail_API_Chamber17.py
```

เมื่อเปลี่ยน request/response model ให้แก้ตัวอย่างในเอกสาร, test contract และ OpenAPI artifact พร้อมกัน เมื่อเปลี่ยน authentication หรือ status code ให้ตรวจ client integration และ CI workflow เพิ่มเติม

## 22. Production checklist

| รายการ | ตรวจสอบ |
|---|---|
| Secret | `ZYRQUEN_API_KEY` มาจาก secret manager และไม่อยู่ใน Git/log |
| Network | port `8000`, `/metrics`, `/docs` และ database ไม่เปิด public โดยไม่จำเป็น |
| TLS | client ใช้ HTTPS และ certificate renewal ผ่านการตรวจสอบ |
| Data | backup และ restore drill ผ่าน พร้อมตรวจ checksum |
| Observability | `X-Request-ID`, metrics, logs และ alerts ทำงาน |
| Deployment | ใช้ image ที่ immutable/pinned และ regression tests ผ่าน |
| Concurrency | หากมีหลาย node ต้องย้ายจาก SQLite ไป database แบบ client/server |

## References

[1]: https://fastapi.tiangolo.com/concepts/openapi/ "FastAPI OpenAPI documentation"
[2]: https://fastapi.tiangolo.com/tutorial/metadata/ "FastAPI metadata and docs URLs"
[3]: https://spec.openapis.org/oas/latest.html "OpenAPI Specification"
