# FastAPI lifespan migration

## การเปลี่ยนแปลง

API เปลี่ยนจาก deprecated `@app.on_event("startup")` เป็น `@asynccontextmanager` lifespan handler:

```python
@asynccontextmanager
async def lifespan(_app: FastAPI):
    init_db()
    yield

app = FastAPI(..., lifespan=lifespan)
```

พฤติกรรมเดิมยังคงอยู่: `init_db()` จะทำงานก่อน application รับ request แรก และยังสร้าง SQLite tables ตามเดิม ไม่มี shutdown resource ที่ต้องปิดในเวอร์ชันนี้ จึงไม่มี cleanup หลัง `yield`

## เหตุผล

Lifespan API รวม startup และ shutdown lifecycle ไว้ใน context เดียว ทำให้ resource initialization/cleanup อยู่ใกล้กันและเข้ากับ FastAPI รุ่นปัจจุบันมากกว่า `on_event`

หากเพิ่ม resource ในอนาคต เช่น database pool, Redis client หรือ telemetry exporter ให้สร้างก่อน `yield` และปิดหลัง `yield` ใน `finally`:

```python
@asynccontextmanager
async def lifespan(_app: FastAPI):
    pool = await create_pool()
    try:
        yield
    finally:
        await pool.close()
```

## การตรวจสอบ

Regression suite ผ่าน **21 API tests** และไม่มี `on_event` deprecation warning เหลืออยู่ มีเพียง warning จาก `httpx/TestClient` dependency ใน environment ทดสอบ
